//! Benchmark: Atomic price store update latency.

use bellman_arb::state::PriceStore;
use criterion::{black_box, criterion_group, criterion_main, Criterion};

fn bench_atomic_update(c: &mut Criterion) {
    let store = PriceStore::new(100);

    c.bench_function("atomic_update_single", |b| {
        let mut i = 0u32;
        b.iter(|| {
            store.update(black_box(i % 100), black_box(40000.0), black_box(40001.0), black_box(1000));
            i = i.wrapping_add(1);
        });
    });

    c.bench_function("atomic_read_ln", |b| {
        store.update(50, 40000.0, 40001.0, 1000);
        b.iter(|| {
            let ln_bid = store.ln_bid(black_box(50));
            let ln_ask = store.ln_ask(black_box(50));
            black_box((ln_bid, ln_ask))
        });
    });
}

criterion_group!(benches, bench_atomic_update);
criterion_main!(benches);
