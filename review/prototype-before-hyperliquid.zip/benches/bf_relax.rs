//! Benchmark: Bellman-Ford relaxation loop.

use bellman_arb::bellman_ford::BfHot;
use bellman_arb::graph::GraphBuilder;
use bellman_arb::state::PriceStore;
use bellman_arb::types::SymbolMeta;
use criterion::{black_box, criterion_group, criterion_main, Criterion};

fn make_symbol(symbol: &str, base: &str, quote: &str) -> SymbolMeta {
    SymbolMeta {
        symbol: symbol.to_string(),
        base_asset: base.to_string(),
        quote_asset: quote.to_string(),
        quote_volume_24h: 1000.0,
    }
}

fn create_test_graph(num_pairs: usize) -> (bellman_arb::graph::Graph, bellman_arb::state::PriceStore) {
    // Create a chain of pairs: A/B, B/C, C/D, ...
    let mut symbols = Vec::with_capacity(num_pairs);
    let currencies: Vec<String> = (0..=num_pairs)
        .map(|i| format!("CUR{}", i))
        .collect();

    for i in 0..num_pairs {
        let symbol = format!("{}_{}", currencies[i], currencies[i + 1]);
        symbols.push(make_symbol(&symbol, &currencies[i], &currencies[i + 1]));
    }

    let builder = GraphBuilder::new();
    let (graph, _meta) = builder.build(&symbols);

    let price_store = PriceStore::new(num_pairs);
    for i in 0..num_pairs {
        price_store.update(i as u32, 100.0, 100.1, 1000);
    }

    (graph, price_store)
}

fn bench_bf_relax(c: &mut Criterion) {
    let (graph, price_store) = create_test_graph(100);
    let k = (1.0 - 0.001_f64).ln();

    c.bench_function("bf_relax_100_budget", |b| {
        let mut bf = BfHot::new(graph.num_nodes as usize, k, 256);
        // Enqueue all nodes
        for i in 0..graph.num_nodes {
            bf.on_price_update(i, &graph);
        }

        b.iter(|| {
            bf.relax_budget(black_box(100), &graph, &price_store)
        });
    });

    c.bench_function("bf_relax_500_budget", |b| {
        let mut bf = BfHot::new(graph.num_nodes as usize, k, 256);
        for i in 0..graph.num_nodes {
            bf.on_price_update(i, &graph);
        }

        b.iter(|| {
            bf.relax_budget(black_box(500), &graph, &price_store)
        });
    });
}

criterion_group!(benches, bench_bf_relax);
criterion_main!(benches);
