//! Benchmark: End-to-end latency from price update to decision.

use bellman_arb::bellman_ford::cycle::CycleExtractor;
use bellman_arb::bellman_ford::BfHot;
use bellman_arb::graph::GraphBuilder;
use bellman_arb::ring_buffer::{OverflowPolicy, SpscRingBuffer};
use bellman_arb::state::PriceStore;
use bellman_arb::types::{BestBidAskUpdate, SymbolMeta};
use criterion::{black_box, criterion_group, criterion_main, Criterion};

fn make_symbol(symbol: &str, base: &str, quote: &str) -> SymbolMeta {
    SymbolMeta {
        symbol: symbol.to_string(),
        base_asset: base.to_string(),
        quote_asset: quote.to_string(),
        quote_volume_24h: 1000.0,
    }
}

fn create_triangle_graph() -> (bellman_arb::graph::Graph, PriceStore) {
    let symbols = vec![
        make_symbol("BTCUSDT", "BTC", "USDT"),
        make_symbol("ETHUSDT", "ETH", "USDT"),
        make_symbol("ETHBTC", "ETH", "BTC"),
    ];

    let builder = GraphBuilder::new();
    let (graph, _meta) = builder.build(&symbols);

    let price_store = PriceStore::new(3);
    price_store.update(0, 40000.0, 40010.0, 1000);
    price_store.update(1, 2000.0, 2001.0, 1000);
    price_store.update(2, 0.05, 0.05001, 1000);

    (graph, price_store)
}

fn bench_end_to_end(c: &mut Criterion) {
    let (graph, price_store) = create_triangle_graph();
    let k = (1.0 - 0.001_f64).ln();

    c.bench_function("e2e_update_and_check", |b| {
        let mut bf = BfHot::new(graph.num_nodes as usize, k, 256);
        let mut extractor = CycleExtractor::new(6);

        b.iter(|| {
            // Simulate price update
            let update = BestBidAskUpdate::new(0, 40000.0, 40010.0, 2000);
            price_store.update(update.symbol_index, update.bid(), update.ask(), update.ts_ns);
            bf.on_price_update(update.symbol_index, &graph);

            // Run BF
            let result = bf.relax_budget(black_box(500), &graph, &price_store);

            // Extract cycle if found
            if let Some(node) = result {
                let (pred_node, pred_edge) = bf.predecessors();
                let _cycle = extractor.extract(
                    node,
                    pred_node,
                    pred_edge,
                    graph.num_nodes as usize,
                );
            }

            black_box(result)
        });
    });

    c.bench_function("ring_buffer_push_pop", |b| {
        let buffer: SpscRingBuffer<BestBidAskUpdate> =
            SpscRingBuffer::new(4096, OverflowPolicy::DropNewest);

        b.iter(|| {
            let update = BestBidAskUpdate::new(0, 40000.0, 40010.0, 2000);
            buffer.try_push(black_box(update));
            buffer.try_pop()
        });
    });
}

criterion_group!(benches, bench_end_to_end);
criterion_main!(benches);
