# Bellman-Arb

Ultra-low-latency arbitrage detector using Bellman-Ford negative cycle detection.

## Overview

Bellman-Arb is a high-performance Rust system that:
- Ingests real-time best bid/ask data via WebSockets (Binance)
- Maintains lock-free atomic price state
- Detects arbitrage opportunities using Bellman-Ford algorithm
- Tracks opportunity lifecycles with sub-millisecond precision

**Primary KPI:** WebSocket message to arbitrage decision latency < 150 microseconds (p99).

## Architecture

### Hot Path (Latency-Critical)
- No locks, no heap allocations after init, no logging
- Atomic price updates with pre-computed ln values
- Incremental budgeted Bellman-Ford relaxation (SPFA-like)
- Lock-free SPSC ring buffers for data flow

### Cold Path
- Exchange REST API for pair discovery
- WebSocket connection management
- Periodic full Bellman-Ford discovery
- Logging thread for event output

## Quick Start

```bash
# Build
cargo build --release

# Run with default config
./target/release/bellman-arb

# Run with custom config
./target/release/bellman-arb path/to/config.toml
```

## Configuration

Edit `config.toml`:

```toml
exchange = "binance"        # Exchange to connect to
top_pairs = 100             # Number of top pairs by 24h volume
quote_filter = "USDT"       # Filter pairs by quote asset
fee_bps = 10                # Trading fee (10 = 0.1%)
min_profit_bps = 5          # Minimum profit threshold (5 = 0.05%)
stale_ns = 5_000_000_000    # Price staleness threshold (5 seconds)
grace_ns = 1_000_000_000    # Opportunity grace period (1 second)
bf_discovery_interval_ms = 10_000  # Cold BF interval
max_relaxations_per_tick = 500     # Hot BF budget per tick
max_cycle_len = 6           # Maximum arbitrage cycle length
log_free = false            # Disable logging for minimum latency
```

## Project Structure

```
bellman-arb/
├── src/
│   ├── main.rs              # Entry point and hot-path loop
│   ├── lib.rs               # Library exports
│   ├── config.rs            # Configuration loading
│   ├── types.rs             # Core data types
│   ├── stats.rs             # Atomic statistics counters
│   ├── bellman_ford/        # BF algorithm (hot + cold)
│   ├── collectors/          # Exchange collectors (Binance)
│   ├── graph/               # Graph representation (CSR)
│   ├── state/               # Atomic price store
│   ├── ring_buffer/         # Lock-free SPSC buffers
│   ├── timing/              # Opportunity tracker
│   └── logging/             # Cold-path logging thread
├── examples/                # Example code
├── tests/                   # Integration tests
├── benches/                 # Performance benchmarks
├── DOCS/                    # Documentation
│   └── PRD.md              # Product requirements
├── Cargo.toml              # Dependencies
└── config.toml             # Default configuration
```

## How It Works

### Graph Model
Each trading pair creates two directed edges:
- **SELL edge**: BASE → QUOTE (uses bid price)
- **BUY edge**: QUOTE → BASE (uses ask price)

Edge weights are computed as negative log returns including fees:
- SELL: `w = -(ln(bid) + ln(1-fee))`
- BUY: `w = ln(ask) - ln(1-fee)`

A negative cycle in this graph represents an arbitrage opportunity.

### Bellman-Ford Detection
1. **BF-HOT (Hot Path)**: Incremental relaxation triggered by price updates
   - Only relaxes affected nodes (dirty-region optimization)
   - Budgeted per tick to maintain latency
   - Detects negative cycles via relaxation count > N

2. **BF-COLD (Cold Path)**: Periodic full graph scan
   - Ensures all cycles are eventually discovered
   - Produces candidate set for hot path validation

### Opportunity Tracking
- Cycles are canonicalized to unique signatures
- Timing tracks: start, duration, max profit
- Grace period prevents flapping on brief price changes
- Stale prices invalidate cycles immediately

## Performance Targets

| Stage | Target |
|-------|--------|
| WS receive → normalized update | p99 < 50 µs |
| Normalized update → atomic write | p99 < 10 µs |
| Atomic read → BF evaluate | p99 < 50 µs |
| **End-to-end WS → decision** | **p99 < 150 µs** |

## Benchmarks

```bash
# Run all benchmarks
cargo bench

# Specific benchmarks
cargo bench --bench atomic_update
cargo bench --bench bf_relax
cargo bench --bench end_to_end
```

## Dependencies

- **tokio**: Async runtime (cold path only)
- **simd-json**: Fast JSON parsing for WebSocket messages
- **tokio-tungstenite**: WebSocket client
- **reqwest**: HTTP client for REST API
- **tracing**: Logging (cold path only)

## License

Proprietary
