// Standalone review checks against the real source; no external dependencies.
// The cold worker's debug log is suppressed in this isolated algorithm harness.
extern crate self as tracing;
#[macro_export]
macro_rules! debug { ($($args:tt)*) => {{ let _ = format_args!($($args)*); }}; }
#[path = "../src/types.rs"] mod types;
#[path = "../src/graph/mod.rs"] mod graph;
#[path = "../src/state/mod.rs"] mod state;
#[path = "../src/bellman_ford/weights.rs"] pub mod weights;
mod bellman_ford { pub use crate::{weights, cycle}; }
#[path = "../src/bellman_ford/hot.rs"] mod hot;
#[path = "../src/bellman_ford/cycle.rs"] pub mod cycle;
#[path = "../src/bellman_ford/cold.rs"] mod cold;

fn symbol(base: &str, quote: &str) -> types::SymbolMeta {
    types::SymbolMeta { symbol: format!("{base}{quote}"), base_asset: base.into(),
        quote_asset: quote.into(), quote_volume_24h: 1.0 }
}

#[test]
fn review_budget_must_not_change_detection() {
    let (g, _) = graph::GraphBuilder::new().build(&[
        symbol("BTC", "USDT"), symbol("ETH", "USDT"), symbol("ETH", "BTC")]);
    let p = state::PriceStore::new(3);
    p.update(0, 40000.0, 40010.0, 1);
    p.update(1, 2100.0, 2101.0, 1);
    p.update(2, 0.05, 0.05001, 1);
    let k = 0.999_f64.ln();
    // Independent direct conversion: USDT -> BTC -> ETH -> USDT.
    assert!(2100.0 / (40010.0 * 0.05001) * 0.999_f64.powi(3) > 1.0);
    let detects = |budget| {
        let mut bf = hot::BfHot::new(3, k, 16);
        for s in 0..3 { bf.on_price_update(s, &g); }
        (0..1000).any(|_| bf.relax_budget(budget, &g, &p).is_some())
    };
    assert!(detects(500));
    assert!(detects(1), "same profitable graph is missed with budget=1");
}

#[test]
fn review_price_changes_are_not_negative_cycles() {
    let (g, _) = graph::GraphBuilder::new().build(&[symbol("BTC", "USDT")]);
    let p = state::PriceStore::new(1);
    let mut bf = hot::BfHot::new(2, 0.999_f64.ln(), 16);
    for n in 0..10 {
        let bid = 100.0 + n as f64;
        p.update(0, bid, bid + 1.0, n + 1);
        bf.on_price_update(0, &g);
        // The only possible round trip loses spread plus two fees.
        assert!(bid / (bid + 1.0) * 0.999_f64.powi(2) < 1.0);
        assert!(bf.relax_budget(500, &g, &p).is_none(),
            "reported a negative cycle in a non-crossed single market at update {n}");
    }
}

#[test]
fn review_expired_slots_must_be_reusable() {
    let s = state::OpportunityStore::new(1);
    assert_eq!(s.update(1, 0.01, 1), state::UpdateResult::Started);
    s.expire_stale(10, 1, |_| {});
    assert_eq!(s.update(2, 0.01, 11), state::UpdateResult::Started);
}

#[test]
fn review_extracted_edges_must_form_a_forward_route() {
    let (g, _) = graph::GraphBuilder::new().build(&[
        symbol("A", "B"), symbol("B", "C"), symbol("C", "A")]);
    let mut extractor = cycle::CycleExtractor::new(6);
    let edges = extractor.extract(0, &[2, 0, 1], &[4, 0, 2], 3).unwrap();
    for i in 0..edges.len() {
        assert_eq!(g.edge_to(edges[i]), g.edge_from(edges[(i + 1) % edges.len()]));
    }
}

#[test]
fn review_cold_claim_of_all_cycles_includes_overlapping_routes() {
    let (g, _) = graph::GraphBuilder::new().build(&[
        symbol("A", "B"), symbol("B", "C"), symbol("C", "A"),
        symbol("B", "D"), symbol("D", "A")]);
    let bids: [f64; 5] = [1.0, 1.0, 1.02, 1.0, 1.01];
    let asks: [f64; 5] = [1.001, 1.001, 1.021, 1.001, 1.011];
    let ln_bids = bids.map(f64::ln);
    let ln_asks = asks.map(f64::ln);
    let k = 0.999_f64.ln();
    // Independently verify both A->B->C->A and A->B->D->A.
    assert!(bids[0] * bids[1] * bids[2] * 0.999_f64.powi(3) > 1.0);
    assert!(bids[0] * bids[3] * bids[4] * 0.999_f64.powi(3) > 1.0);
    let mut bf = cold::BfCold::new(4, k, 6, 100);
    let found = bf.discover(&g, &ln_bids, &ln_asks);
    let mut routes: Vec<Vec<u32>> = found.iter().map(|c| {
        let mut edges = c.edges.clone();
        edges.sort_unstable();
        edges
    }).collect();
    routes.sort();
    assert!(routes.contains(&vec![0, 2, 4]) && routes.contains(&vec![0, 6, 8]),
        "two verified profitable triangles exist, but cold discovery returned {routes:?}");
}

#[test]
fn review_rounding_must_not_promote_a_subthreshold_gain() {
    let gain = 1.0 + 4.6 / 10_000.0_f64;
    let threshold_bps = 5;
    assert!(gain < 1.0 + threshold_bps as f64 / 10_000.0);
    // main.rs passes this rounded value to the tracker's integer threshold test.
    let reported_bps = weights::cycle_weight_to_profit_bps(-gain.ln());
    assert!(reported_bps < threshold_bps,
        "4.6 bps is rounded to {reported_bps} and passes the 5 bps filter");
}
