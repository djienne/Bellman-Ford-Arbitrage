//! Hot-path incremental budgeted Bellman-Ford.
//!
//! This is the core of the arbitrage detection system. It maintains
//! BF state and runs incremental relaxations with a work budget.
//!
//! # Design Constraints
//! - No allocations after initialization
//! - No locks
//! - No logging
//! - No dynamic dispatch
//! - Strict work budget per tick

use crate::bellman_ford::weights::compute_edge_weight_from_store;
use crate::graph::Graph;
use crate::state::PriceStore;

/// Small epsilon for floating point comparison.
const EPSILON: f64 = 1e-12;

/// Hot-path Bellman-Ford state.
pub struct BfHot {
    /// Distance from "source" (initialized to 0 for all nodes)
    dist: Vec<f64>,
    /// Predecessor node (-1 = none)
    pred_node: Vec<i32>,
    /// Predecessor edge (-1 = none)
    pred_edge: Vec<i32>,
    /// Relaxation count per node (for cycle detection)
    relax_count: Vec<u32>,
    /// In-queue flags (1 = in queue, 0 = not)
    in_queue: Vec<u8>,
    /// Active queue (ring buffer of node indices)
    queue: Vec<u32>,
    /// Queue head (read position)
    queue_head: usize,
    /// Queue tail (write position)
    queue_tail: usize,
    /// Queue capacity mask
    queue_mask: usize,
    /// Number of nodes
    num_nodes: usize,
    /// Fee factor: ln(1 - fee)
    k: f64,
}

impl BfHot {
    /// Create a new BF hot-path state.
    ///
    /// # Arguments
    /// * `num_nodes` - Number of currency nodes
    /// * `k` - Precomputed ln(1 - fee)
    /// * `queue_capacity` - Capacity for active queue (power of 2)
    pub fn new(num_nodes: usize, k: f64, queue_capacity: usize) -> Self {
        assert!(queue_capacity.is_power_of_two());

        Self {
            dist: vec![0.0; num_nodes],
            pred_node: vec![-1; num_nodes],
            pred_edge: vec![-1; num_nodes],
            relax_count: vec![0; num_nodes],
            in_queue: vec![0; num_nodes],
            queue: vec![0; queue_capacity],
            queue_head: 0,
            queue_tail: 0,
            queue_mask: queue_capacity - 1,
            num_nodes,
            k,
        }
    }

    /// Reset all state for a fresh BF computation.
    pub fn reset(&mut self) {
        for i in 0..self.num_nodes {
            self.dist[i] = 0.0;
            self.pred_node[i] = -1;
            self.pred_edge[i] = -1;
            self.relax_count[i] = 0;
            self.in_queue[i] = 0;
        }
        self.queue_head = 0;
        self.queue_tail = 0;
    }

    /// Check if the queue is empty.
    #[inline(always)]
    fn queue_is_empty(&self) -> bool {
        self.queue_head == self.queue_tail
    }

    /// Enqueue a node if not already in queue.
    #[inline(always)]
    fn enqueue(&mut self, node: u32) {
        if self.in_queue[node as usize] == 0 {
            self.in_queue[node as usize] = 1;
            self.queue[self.queue_tail & self.queue_mask] = node;
            self.queue_tail = self.queue_tail.wrapping_add(1);
        }
    }

    /// Dequeue a node.
    #[inline(always)]
    fn dequeue(&mut self) -> u32 {
        let node = self.queue[self.queue_head & self.queue_mask];
        self.queue_head = self.queue_head.wrapping_add(1);
        self.in_queue[node as usize] = 0;
        node
    }

    /// Handle a price update by enqueuing affected nodes.
    ///
    /// Called when a symbol's price changes. Enqueues the source nodes
    /// of the two edges (SELL and BUY) associated with the symbol.
    #[inline]
    pub fn on_price_update(&mut self, symbol_index: u32, graph: &Graph) {
        // Each symbol has two edges: SELL at 2*i, BUY at 2*i+1
        let sell_edge = symbol_index * 2;
        let buy_edge = symbol_index * 2 + 1;

        // Enqueue source nodes of affected edges
        if (sell_edge as usize) < graph.edge_from.len() {
            self.enqueue(graph.edge_from(sell_edge));
        }
        if (buy_edge as usize) < graph.edge_from.len() {
            self.enqueue(graph.edge_from(buy_edge));
        }
    }

    /// Run budgeted relaxation.
    ///
    /// Processes nodes from the active queue, relaxing outgoing edges.
    /// Stops when budget is exhausted or queue is empty.
    ///
    /// # Arguments
    /// * `budget` - Maximum number of relaxations to perform
    /// * `graph` - Graph structure
    /// * `price_store` - Atomic price store
    ///
    /// # Returns
    /// `Some(node)` if a negative cycle was detected through `node`, `None` otherwise.
    #[inline]
    pub fn relax_budget(
        &mut self,
        budget: u32,
        graph: &Graph,
        price_store: &PriceStore,
    ) -> Option<u32> {
        let mut relaxations = 0u32;

        while relaxations < budget && !self.queue_is_empty() {
            let u = self.dequeue();
            let dist_u = self.dist[u as usize];

            // Relax all outgoing edges from u
            for &edge_idx in graph.outgoing_edges(u) {
                let v = graph.edge_to(edge_idx);
                let symbol = graph.edge_symbol(edge_idx);
                let kind = graph.edge_kind(edge_idx);

                // Compute edge weight
                let w = compute_edge_weight_from_store(kind, symbol, price_store, self.k);

                // Relaxation check
                let new_dist = dist_u + w;
                if new_dist < self.dist[v as usize] - EPSILON {
                    self.dist[v as usize] = new_dist;
                    self.pred_node[v as usize] = u as i32;
                    self.pred_edge[v as usize] = edge_idx as i32;
                    self.relax_count[v as usize] += 1;

                    // Negative cycle detection: if relaxed more than N times
                    if self.relax_count[v as usize] > self.num_nodes as u32 {
                        return Some(v);
                    }

                    self.enqueue(v);
                }

                relaxations += 1;
                if relaxations >= budget {
                    break;
                }
            }
        }

        None
    }

    /// Run a full BF pass (V-1 iterations) without budget.
    /// Used for testing and cold path comparison.
    pub fn run_full(&mut self, graph: &Graph, price_store: &PriceStore) -> Option<u32> {
        // Initialize: enqueue all nodes
        for node in 0..self.num_nodes {
            self.enqueue(node as u32);
        }

        // Run V-1 iterations
        for _ in 0..self.num_nodes {
            if self.queue_is_empty() {
                break;
            }

            // Process all currently queued nodes
            let current_tail = self.queue_tail;
            while self.queue_head != current_tail {
                let u = self.dequeue();
                let dist_u = self.dist[u as usize];

                for &edge_idx in graph.outgoing_edges(u) {
                    let v = graph.edge_to(edge_idx);
                    let symbol = graph.edge_symbol(edge_idx);
                    let kind = graph.edge_kind(edge_idx);

                    let w = compute_edge_weight_from_store(kind, symbol, price_store, self.k);
                    let new_dist = dist_u + w;

                    if new_dist < self.dist[v as usize] - EPSILON {
                        self.dist[v as usize] = new_dist;
                        self.pred_node[v as usize] = u as i32;
                        self.pred_edge[v as usize] = edge_idx as i32;
                        self.relax_count[v as usize] += 1;

                        if self.relax_count[v as usize] > self.num_nodes as u32 {
                            return Some(v);
                        }

                        self.enqueue(v);
                    }
                }
            }
        }

        // One more iteration to detect negative cycles
        while !self.queue_is_empty() {
            let u = self.dequeue();
            let dist_u = self.dist[u as usize];

            for &edge_idx in graph.outgoing_edges(u) {
                let v = graph.edge_to(edge_idx);
                let symbol = graph.edge_symbol(edge_idx);
                let kind = graph.edge_kind(edge_idx);

                let w = compute_edge_weight_from_store(kind, symbol, price_store, self.k);
                let new_dist = dist_u + w;

                if new_dist < self.dist[v as usize] - EPSILON {
                    // Still relaxing in Vth iteration = negative cycle
                    return Some(v);
                }
            }
        }

        None
    }

    /// Get the predecessor arrays for cycle extraction.
    pub fn predecessors(&self) -> (&[i32], &[i32]) {
        (&self.pred_node, &self.pred_edge)
    }

    /// Get distance for a node.
    #[inline]
    pub fn dist(&self, node: u32) -> f64 {
        self.dist[node as usize]
    }

    /// Decay distances toward 0 (for periodic reset).
    pub fn decay_distances(&mut self, factor: f64) {
        for d in self.dist.iter_mut() {
            *d *= factor;
        }
    }

    /// Reset relax counts (call periodically to allow re-detection).
    pub fn reset_relax_counts(&mut self) {
        for c in self.relax_count.iter_mut() {
            *c = 0;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::graph::GraphBuilder;
    use crate::state::PriceStore;
    use crate::types::SymbolMeta;

    fn make_symbol(symbol: &str, base: &str, quote: &str) -> SymbolMeta {
        SymbolMeta {
            symbol: symbol.to_string(),
            base_asset: base.to_string(),
            quote_asset: quote.to_string(),
            quote_volume_24h: 1000.0,
        }
    }

    #[test]
    fn test_no_arbitrage() {
        // Create a triangle with no arbitrage opportunity
        let symbols = vec![
            make_symbol("BTCUSDT", "BTC", "USDT"),
            make_symbol("ETHUSDT", "ETH", "USDT"),
            make_symbol("ETHBTC", "ETH", "BTC"),
        ];

        let builder = GraphBuilder::new();
        let (graph, _meta) = builder.build(&symbols);

        let price_store = PriceStore::new(3);
        // Set prices that don't create arbitrage
        // BTC/USDT: bid=40000, ask=40010
        // ETH/USDT: bid=2000, ask=2001
        // ETH/BTC: bid=0.05, ask=0.05001
        price_store.update(0, 40000.0, 40010.0, 1000);
        price_store.update(1, 2000.0, 2001.0, 1000);
        price_store.update(2, 0.05, 0.05001, 1000);

        let k = (1.0_f64 - 0.001).ln(); // 0.1% fee
        let mut bf = BfHot::new(graph.num_nodes as usize, k, 16);

        let result = bf.run_full(&graph, &price_store);
        assert!(result.is_none(), "Should not find arbitrage");
    }

    #[test]
    fn test_with_arbitrage() {
        // Create a triangle with arbitrage opportunity
        let symbols = vec![
            make_symbol("BTCUSDT", "BTC", "USDT"),
            make_symbol("ETHUSDT", "ETH", "USDT"),
            make_symbol("ETHBTC", "ETH", "BTC"),
        ];

        let builder = GraphBuilder::new();
        let (graph, _meta) = builder.build(&symbols);

        let price_store = PriceStore::new(3);
        // Set prices that create arbitrage (unrealistic but tests the algorithm)
        // Path: USDT -> BTC -> ETH -> USDT
        // Buy BTC with USDT at ask, sell ETH for BTC at ask (buy ETH), sell ETH for USDT at bid
        price_store.update(0, 40000.0, 39000.0, 1000); // Inverted spread!
        price_store.update(1, 2100.0, 2000.0, 1000); // Inverted spread!
        price_store.update(2, 0.052, 0.05, 1000); // Inverted spread!

        let k = (1.0_f64 - 0.001).ln(); // 0.1% fee
        let mut bf = BfHot::new(graph.num_nodes as usize, k, 16);

        let result = bf.run_full(&graph, &price_store);
        assert!(result.is_some(), "Should find arbitrage with inverted spreads");
    }

    #[test]
    fn test_incremental_update() {
        let symbols = vec![
            make_symbol("BTCUSDT", "BTC", "USDT"),
            make_symbol("ETHUSDT", "ETH", "USDT"),
        ];

        let builder = GraphBuilder::new();
        let (graph, _meta) = builder.build(&symbols);

        let k = (1.0_f64 - 0.001).ln();
        let mut bf = BfHot::new(graph.num_nodes as usize, k, 16);

        // Simulate price update
        bf.on_price_update(0, &graph);

        // Queue should have nodes
        assert!(!bf.queue_is_empty());
    }
}
