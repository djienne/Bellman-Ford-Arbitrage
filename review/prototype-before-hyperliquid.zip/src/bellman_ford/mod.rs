//! Bellman-Ford algorithm implementations.
//!
//! Two implementations are provided:
//! - `BfHot`: Incremental, budgeted BF for hot path
//! - `BfCold`: Full BF discovery for cold path

mod cold;
pub mod cycle;
mod hot;
pub mod weights;

pub use cold::{BfCold, BfColdThread, CandidateCycle, CandidateSet, ColdThreadConfig};
pub use cycle::{canonicalize_cycle, cycle_has_stale_edge, CycleExtractor};
pub use hot::BfHot;
pub use weights::compute_edge_weight;
