//! Edge weight computation for Bellman-Ford.
//!
//! Weights are computed from precomputed ln(price) values to avoid
//! calling ln() in the hot path.

use crate::state::PriceStore;
use crate::types::EDGE_SELL_BID;

/// Compute the edge weight for Bellman-Ford.
///
/// For arbitrage detection, we convert rates to log space and negate:
/// - A profitable cycle has product of rates > 1
/// - In log space: sum of ln(rates) > 0
/// - For BF negative cycle detection: sum of -ln(rates) < 0
///
/// Fee is applied to each hop: effective_rate = raw_rate * (1 - fee)
///
/// # Arguments
/// * `edge_kind` - EDGE_SELL_BID or EDGE_BUY_ASK
/// * `ln_bid` - ln(bid price) from price store
/// * `ln_ask` - ln(ask price) from price store
/// * `k` - ln(1 - fee), precomputed constant
///
/// # Returns
/// Edge weight for BF relaxation
#[inline(always)]
pub fn compute_edge_weight(edge_kind: u8, ln_bid: f64, ln_ask: f64, k: f64) -> f64 {
    if edge_kind == EDGE_SELL_BID {
        // SELL: BASE -> QUOTE
        // Rate = bid * (1 - fee)
        // ln(rate) = ln(bid) + ln(1-fee) = ln_bid + k
        // Weight = -ln(rate) = -(ln_bid + k)
        -(ln_bid + k)
    } else {
        // BUY: QUOTE -> BASE
        // Rate = (1/ask) * (1 - fee) = (1-fee)/ask
        // ln(rate) = ln(1-fee) - ln(ask) = k - ln_ask
        // Weight = -ln(rate) = -(k - ln_ask) = ln_ask - k
        ln_ask - k
    }
}

/// Compute edge weight directly from price store.
#[inline(always)]
pub fn compute_edge_weight_from_store(
    edge_kind: u8,
    symbol_index: u32,
    price_store: &PriceStore,
    k: f64,
) -> f64 {
    let ln_bid = price_store.ln_bid(symbol_index);
    let ln_ask = price_store.ln_ask(symbol_index);
    compute_edge_weight(edge_kind, ln_bid, ln_ask, k)
}

/// Compute edge weight with staleness check.
/// Returns INFINITY if the price is stale, making the edge unusable for arbitrage.
#[inline(always)]
pub fn compute_edge_weight_with_staleness(
    edge_kind: u8,
    symbol_index: u32,
    price_store: &PriceStore,
    k: f64,
    now_ns: u64,
    stale_threshold_ns: u64,
) -> f64 {
    if price_store.is_stale(symbol_index, now_ns, stale_threshold_ns) {
        return f64::INFINITY;
    }
    compute_edge_weight_from_store(edge_kind, symbol_index, price_store, k)
}

/// Compute the actual profit multiplier for a cycle.
///
/// Given edge weights that sum to a negative value, compute the actual
/// profit as a multiplier (e.g., 1.005 = 0.5% profit).
#[inline]
pub fn cycle_weight_to_profit(total_weight: f64) -> f64 {
    // total_weight = sum of -ln(rates)
    // sum of ln(rates) = -total_weight
    // product of rates = exp(-total_weight)
    (-total_weight).exp()
}

/// Compute profit in basis points from a cycle weight.
#[inline]
pub fn cycle_weight_to_profit_bps(total_weight: f64) -> u32 {
    let profit = cycle_weight_to_profit(total_weight);
    if profit > 1.0 {
        ((profit - 1.0) * 10_000.0).round() as u32
    } else {
        0
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::types::EDGE_BUY_ASK;

    #[test]
    fn test_sell_weight() {
        // Bid = 100, fee = 0.1%
        let ln_bid = 100.0_f64.ln();
        let k = (1.0_f64 - 0.001).ln(); // ln(0.999)

        let weight = compute_edge_weight(EDGE_SELL_BID, ln_bid, 0.0, k);

        // Expected: -(ln(100) + ln(0.999)) = -ln(100 * 0.999) = -ln(99.9)
        let expected = -(ln_bid + k);
        assert!((weight - expected).abs() < 1e-10);
    }

    #[test]
    fn test_buy_weight() {
        // Ask = 100, fee = 0.1%
        let ln_ask = 100.0_f64.ln();
        let k = (1.0_f64 - 0.001).ln();

        let weight = compute_edge_weight(EDGE_BUY_ASK, 0.0, ln_ask, k);

        // Expected: ln(100) - ln(0.999) = ln(100/0.999)
        let expected = ln_ask - k;
        assert!((weight - expected).abs() < 1e-10);
    }

    #[test]
    fn test_profit_conversion() {
        // A cycle with 0.5% profit
        // Product of rates = 1.005
        // Sum of ln(rates) = ln(1.005)
        // Sum of weights = -ln(1.005)
        let total_weight = -(1.005_f64.ln());

        let profit = cycle_weight_to_profit(total_weight);
        assert!((profit - 1.005).abs() < 1e-6);

        let bps = cycle_weight_to_profit_bps(total_weight);
        assert_eq!(bps, 50); // 0.5% = 50 bps
    }
}
