//! Cycle extraction and canonicalization.
//!
//! Extracts negative cycles from BF predecessor chains and computes
//! canonical signatures for opportunity identification.

use crate::graph::Graph;
use crate::state::PriceStore;

/// Cycle extractor with preallocated scratch space.
pub struct CycleExtractor {
    /// Scratch buffer for collecting cycle edges
    edge_scratch: Vec<u32>,
    /// Scratch buffer for collecting cycle nodes
    node_scratch: Vec<u32>,
    /// Scratch buffer for canonicalization (currency_id, direction) pairs
    canon_scratch: Vec<(u32, u8)>,
    /// Maximum cycle length
    max_len: usize,
}

impl CycleExtractor {
    /// Create a new cycle extractor.
    pub fn new(max_cycle_len: usize) -> Self {
        Self {
            edge_scratch: vec![0; max_cycle_len],
            node_scratch: vec![0; max_cycle_len],
            canon_scratch: vec![(0, 0); max_cycle_len],
            max_len: max_cycle_len,
        }
    }

    /// Extract a cycle starting from a node known to be in a negative cycle.
    ///
    /// # Arguments
    /// * `start_node` - Node detected with relax_count > N
    /// * `pred_node` - Predecessor node array from BF
    /// * `pred_edge` - Predecessor edge array from BF
    /// * `num_nodes` - Total number of nodes in graph
    ///
    /// # Returns
    /// Slice of edge indices forming the cycle, or None if extraction fails.
    pub fn extract(
        &mut self,
        start_node: u32,
        pred_node: &[i32],
        pred_edge: &[i32],
        num_nodes: usize,
    ) -> Option<&[u32]> {
        // Walk back N steps to ensure we're inside the cycle
        let mut node = start_node;
        for _ in 0..num_nodes {
            let pred = pred_node[node as usize];
            if pred < 0 {
                return None; // No predecessor, can't extract
            }
            node = pred as u32;
        }

        // Now we're guaranteed to be in the cycle
        let cycle_start = node;
        let mut len = 0;

        loop {
            if len >= self.max_len {
                return None; // Cycle too long
            }

            let edge = pred_edge[node as usize];
            if edge < 0 {
                return None; // Invalid predecessor
            }

            self.edge_scratch[len] = edge as u32;
            self.node_scratch[len] = node;
            len += 1;

            let pred = pred_node[node as usize];
            if pred < 0 {
                return None;
            }
            node = pred as u32;

            if node == cycle_start {
                break;
            }
        }

        Some(&self.edge_scratch[..len])
    }

    /// Get the nodes in the last extracted cycle.
    pub fn cycle_nodes(&self, len: usize) -> &[u32] {
        &self.node_scratch[..len]
    }

    /// Compute a canonical signature for edges using scratch buffer.
    /// Zero-allocation version for hot-path usage.
    #[inline]
    pub fn canonicalize(&mut self, edges: &[u32], graph: &Graph) -> u64 {
        if edges.is_empty() {
            return 0;
        }

        let len = edges.len();
        if len > self.max_len {
            return 0;
        }

        // Build sequence into scratch buffer
        for (i, &edge_idx) in edges.iter().enumerate() {
            let from = graph.edge_from(edge_idx);
            let kind = graph.edge_kind(edge_idx);
            self.canon_scratch[i] = (from, kind);
        }

        // Find the lexicographically smallest rotation
        let mut min_start = 0;
        for start in 1..len {
            if is_smaller_rotation_slice(&self.canon_scratch[..len], start, min_start) {
                min_start = start;
            }
        }

        // Hash the canonical sequence using FNV-1a
        let mut hash: u64 = 0xcbf29ce484222325; // FNV offset basis
        for i in 0..len {
            let idx = (min_start + i) % len;
            let (currency, kind) = self.canon_scratch[idx];

            // Mix in currency ID
            hash ^= currency as u64;
            hash = hash.wrapping_mul(0x100000001b3); // FNV prime

            // Mix in edge direction
            hash ^= kind as u64;
            hash = hash.wrapping_mul(0x100000001b3);
        }

        // Also mix in the cycle length
        hash ^= len as u64;
        hash = hash.wrapping_mul(0x100000001b3);

        hash
    }
}

/// Check if rotation starting at `a` is lexicographically smaller than rotation starting at `b`.
/// Works on a slice without allocation.
#[inline]
fn is_smaller_rotation_slice(seq: &[(u32, u8)], a: usize, b: usize) -> bool {
    let len = seq.len();
    for i in 0..len {
        let ia = (a + i) % len;
        let ib = (b + i) % len;

        let (ca, ka) = seq[ia];
        let (cb, kb) = seq[ib];

        if ca < cb {
            return true;
        }
        if ca > cb {
            return false;
        }
        if ka < kb {
            return true;
        }
        if ka > kb {
            return false;
        }
    }
    false // Equal
}

/// Compute a canonical signature for a cycle.
///
/// The signature is rotation-invariant and direction-aware, allowing
/// identification of equivalent cycles regardless of starting point.
///
/// # Arguments
/// * `edges` - Edge indices forming the cycle
/// * `graph` - Graph for edge lookups
///
/// # Returns
/// 64-bit canonical signature
pub fn canonicalize_cycle(edges: &[u32], graph: &Graph) -> u64 {
    if edges.is_empty() {
        return 0;
    }

    // Build a sequence of (currency_id, direction) pairs
    let len = edges.len();
    let mut sequence: Vec<(u32, u8)> = Vec::with_capacity(len);

    for &edge_idx in edges {
        let from = graph.edge_from(edge_idx);
        let kind = graph.edge_kind(edge_idx);
        sequence.push((from, kind));
    }

    // Find the lexicographically smallest rotation
    let mut min_start = 0;
    for start in 1..len {
        if is_smaller_rotation(&sequence, start, min_start) {
            min_start = start;
        }
    }

    // Hash the canonical sequence using FNV-1a
    let mut hash: u64 = 0xcbf29ce484222325; // FNV offset basis
    for i in 0..len {
        let idx = (min_start + i) % len;
        let (currency, kind) = sequence[idx];

        // Mix in currency ID
        hash ^= currency as u64;
        hash = hash.wrapping_mul(0x100000001b3); // FNV prime

        // Mix in edge direction
        hash ^= kind as u64;
        hash = hash.wrapping_mul(0x100000001b3);
    }

    // Also mix in the cycle length
    hash ^= len as u64;
    hash = hash.wrapping_mul(0x100000001b3);

    hash
}

/// Check if rotation starting at `a` is lexicographically smaller than rotation starting at `b`.
fn is_smaller_rotation(seq: &[(u32, u8)], a: usize, b: usize) -> bool {
    let len = seq.len();
    for i in 0..len {
        let ia = (a + i) % len;
        let ib = (b + i) % len;

        let (ca, ka) = seq[ia];
        let (cb, kb) = seq[ib];

        if ca < cb {
            return true;
        }
        if ca > cb {
            return false;
        }
        if ka < kb {
            return true;
        }
        if ka > kb {
            return false;
        }
    }
    false // Equal
}

/// Compute the total weight of a cycle from the graph and price store.
pub fn compute_cycle_weight(
    edges: &[u32],
    graph: &Graph,
    price_store: &PriceStore,
    k: f64,
) -> f64 {
    let mut total = 0.0;
    for &edge_idx in edges {
        let symbol = graph.edge_symbol(edge_idx);
        let kind = graph.edge_kind(edge_idx);
        let weight =
            crate::bellman_ford::weights::compute_edge_weight_from_store(kind, symbol, price_store, k);
        total += weight;
    }
    total
}

/// Check if any edge in the cycle has stale price data.
#[inline]
pub fn cycle_has_stale_edge(
    edges: &[u32],
    graph: &Graph,
    price_store: &PriceStore,
    now_ns: u64,
    stale_threshold_ns: u64,
) -> bool {
    for &edge_idx in edges {
        let symbol = graph.edge_symbol(edge_idx);
        if price_store.is_stale(symbol, now_ns, stale_threshold_ns) {
            return true;
        }
    }
    false
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::types::{EDGE_BUY_ASK, EDGE_SELL_BID};

    /// Create a simple test graph with 3 currencies forming a triangle.
    fn create_test_graph() -> Graph {
        // Triangle: A(0) -> B(1) -> C(2) -> A(0)
        // Each edge has a symbol index and direction
        Graph {
            num_nodes: 3,
            num_edges: 6,
            // Edges: 0=A->B sell, 1=B->A buy, 2=B->C sell, 3=C->B buy, 4=C->A sell, 5=A->C buy
            edge_from: vec![0, 1, 1, 2, 2, 0],
            edge_to: vec![1, 0, 2, 1, 0, 2],
            edge_kind: vec![
                EDGE_SELL_BID,
                EDGE_BUY_ASK,
                EDGE_SELL_BID,
                EDGE_BUY_ASK,
                EDGE_SELL_BID,
                EDGE_BUY_ASK,
            ],
            edge_symbol: vec![0, 0, 1, 1, 2, 2],
            out_start: vec![0, 2, 4, 6],
            out_edges: vec![0, 5, 1, 2, 3, 4],
        }
    }

    #[test]
    fn test_canonicalize_rotation_invariance() {
        let graph = create_test_graph();

        // Cycle: A -> B -> C -> A (edges 0, 2, 4)
        let cycle1 = vec![0, 2, 4]; // Starting from A
        let cycle2 = vec![2, 4, 0]; // Starting from B (rotated)
        let cycle3 = vec![4, 0, 2]; // Starting from C (rotated)

        // All rotations should produce the same canonical signature
        let sig1 = canonicalize_cycle(&cycle1, &graph);
        let sig2 = canonicalize_cycle(&cycle2, &graph);
        let sig3 = canonicalize_cycle(&cycle3, &graph);

        assert_eq!(sig1, sig2, "Rotation invariance failed: sig1 != sig2");
        assert_eq!(sig2, sig3, "Rotation invariance failed: sig2 != sig3");
    }

    #[test]
    fn test_canonicalize_different_cycles() {
        let graph = create_test_graph();

        // Cycle 1: A -> B -> C -> A (using sell edges: 0, 2, 4)
        let cycle1 = vec![0, 2, 4];

        // Cycle 2: A -> C -> B -> A (different path, using edges 5, 3, 1)
        let cycle2 = vec![5, 3, 1];

        // These are different cycles, so signatures should be different
        let sig1 = canonicalize_cycle(&cycle1, &graph);
        let sig2 = canonicalize_cycle(&cycle2, &graph);

        assert_ne!(
            sig1, sig2,
            "Different cycles should have different signatures"
        );
    }

    #[test]
    fn test_extractor_canonicalize_matches_free_function() {
        let graph = create_test_graph();
        let mut extractor = CycleExtractor::new(6);

        let cycle = vec![0, 2, 4];

        let sig_free = canonicalize_cycle(&cycle, &graph);
        let sig_method = extractor.canonicalize(&cycle, &graph);

        assert_eq!(
            sig_free, sig_method,
            "Method and free function should produce same result"
        );
    }

    #[test]
    fn test_rotation_comparison() {
        let seq = vec![(1, 0), (2, 0), (3, 0)];

        // Rotation starting at 0: (1,0), (2,0), (3,0)
        // Rotation starting at 1: (2,0), (3,0), (1,0)
        // Rotation starting at 2: (3,0), (1,0), (2,0)
        // Smallest is rotation at 0 (starts with 1)

        assert!(!is_smaller_rotation(&seq, 1, 0)); // 1 is not smaller than 0
        assert!(!is_smaller_rotation(&seq, 2, 0)); // 2 is not smaller than 0
    }

    #[test]
    fn test_empty_cycle() {
        let graph = create_test_graph();

        let sig = canonicalize_cycle(&[], &graph);
        assert_eq!(sig, 0, "Empty cycle should have zero signature");
    }
}
