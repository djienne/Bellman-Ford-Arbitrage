//! Cold-path full Bellman-Ford discovery.
//!
//! Runs periodically to find all negative cycles and publish
//! a candidate set to the hot path via double-buffered arrays.

use crate::bellman_ford::cycle::{canonicalize_cycle, CycleExtractor};
use crate::bellman_ford::weights::{compute_edge_weight, cycle_weight_to_profit_bps};
use crate::graph::Graph;
use crate::state::PriceStore;
use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};
use std::sync::Arc;
use std::thread;
use std::time::Duration;

/// A candidate cycle discovered by cold BF.
#[derive(Clone, Debug)]
pub struct CandidateCycle {
    /// Canonical signature
    pub signature_id: u64,
    /// Edge indices forming the cycle
    pub edges: Vec<u32>,
    /// Profit in basis points at discovery time
    pub profit_bps: u32,
}

/// Double-buffered candidate set for lock-free hot path access.
/// Uses index-based swapping to avoid unsafe pointer manipulation.
pub struct CandidateSet {
    /// Buffer A
    buffer_a: std::sync::RwLock<Vec<CandidateCycle>>,
    /// Buffer B
    buffer_b: std::sync::RwLock<Vec<CandidateCycle>>,
    /// Index of active buffer (0 = buffer_a, 1 = buffer_b)
    active_index: AtomicUsize,
    /// Number of candidates in active buffer
    count: AtomicUsize,
}

impl CandidateSet {
    /// Create a new candidate set.
    pub fn new(capacity: usize) -> Self {
        Self {
            buffer_a: std::sync::RwLock::new(Vec::with_capacity(capacity)),
            buffer_b: std::sync::RwLock::new(Vec::with_capacity(capacity)),
            active_index: AtomicUsize::new(0),
            count: AtomicUsize::new(0),
        }
    }

    /// Get the current candidate count (for hot path).
    #[inline]
    pub fn count(&self) -> usize {
        self.count.load(Ordering::Acquire)
    }

    /// Get a copy of the active candidates (for hot path).
    /// Returns a clone to avoid holding locks.
    #[inline]
    pub fn candidates(&self) -> Vec<CandidateCycle> {
        let idx = self.active_index.load(Ordering::Acquire);
        let buffer = if idx == 0 {
            self.buffer_a.read().unwrap()
        } else {
            self.buffer_b.read().unwrap()
        };
        buffer.clone()
    }

    /// Publish new candidates from the cold thread.
    /// Fills the inactive buffer, then atomically swaps.
    pub fn publish(&self, candidates: Vec<CandidateCycle>) {
        let count = candidates.len();
        let current_idx = self.active_index.load(Ordering::Acquire);
        let inactive_idx = 1 - current_idx;

        // Write to inactive buffer
        {
            let mut buffer = if inactive_idx == 0 {
                self.buffer_a.write().unwrap()
            } else {
                self.buffer_b.write().unwrap()
            };
            buffer.clear();
            buffer.extend(candidates);
        }

        // Atomic swap: update active index, then count
        self.active_index.store(inactive_idx, Ordering::Release);
        self.count.store(count, Ordering::Release);
    }
}

/// Cold-path Bellman-Ford implementation.
pub struct BfCold {
    /// Distance array
    dist: Vec<f64>,
    /// Predecessor node
    pred_node: Vec<i32>,
    /// Predecessor edge
    pred_edge: Vec<i32>,
    /// In-queue flags
    in_queue: Vec<u8>,
    /// Active queue
    queue: Vec<u32>,
    /// Cycle extractor
    extractor: CycleExtractor,
    /// Found signatures (to avoid duplicates)
    found_signatures: Vec<u64>,
    /// Fee factor
    k: f64,
    /// Maximum candidates
    max_candidates: usize,
}

impl BfCold {
    /// Create a new cold BF instance.
    pub fn new(num_nodes: usize, k: f64, max_cycle_len: usize, max_candidates: usize) -> Self {
        Self {
            dist: vec![0.0; num_nodes],
            pred_node: vec![-1; num_nodes],
            pred_edge: vec![-1; num_nodes],
            in_queue: vec![0; num_nodes],
            queue: Vec::with_capacity(num_nodes),
            extractor: CycleExtractor::new(max_cycle_len),
            found_signatures: Vec::with_capacity(max_candidates),
            k,
            max_candidates,
        }
    }

    /// Run full BF discovery with a price snapshot.
    ///
    /// # Arguments
    /// * `graph` - Graph structure
    /// * `ln_bids` - Snapshot of ln(bid) values per symbol
    /// * `ln_asks` - Snapshot of ln(ask) values per symbol
    ///
    /// # Returns
    /// Vector of discovered candidate cycles
    pub fn discover(
        &mut self,
        graph: &Graph,
        ln_bids: &[f64],
        ln_asks: &[f64],
    ) -> Vec<CandidateCycle> {
        let num_nodes = graph.num_nodes as usize;
        let mut candidates = Vec::new();
        self.found_signatures.clear();

        // Reset state
        for i in 0..num_nodes {
            self.dist[i] = 0.0;
            self.pred_node[i] = -1;
            self.pred_edge[i] = -1;
            self.in_queue[i] = 0;
        }
        self.queue.clear();

        // Initialize: enqueue all nodes
        for node in 0..num_nodes {
            self.queue.push(node as u32);
            self.in_queue[node] = 1;
        }

        // Run V-1 iterations (SPFA style)
        for _iter in 0..num_nodes {
            if self.queue.is_empty() {
                break;
            }

            let batch_size = self.queue.len();
            for _ in 0..batch_size {
                let u = self.queue.remove(0);
                self.in_queue[u as usize] = 0;
                let dist_u = self.dist[u as usize];

                for &edge_idx in graph.outgoing_edges(u) {
                    let v = graph.edge_to(edge_idx);
                    let symbol = graph.edge_symbol(edge_idx);
                    let kind = graph.edge_kind(edge_idx);

                    let ln_bid = ln_bids[symbol as usize];
                    let ln_ask = ln_asks[symbol as usize];
                    let w = compute_edge_weight(kind, ln_bid, ln_ask, self.k);

                    let new_dist = dist_u + w;
                    if new_dist < self.dist[v as usize] - 1e-12 {
                        self.dist[v as usize] = new_dist;
                        self.pred_node[v as usize] = u as i32;
                        self.pred_edge[v as usize] = edge_idx as i32;

                        if self.in_queue[v as usize] == 0 {
                            self.in_queue[v as usize] = 1;
                            self.queue.push(v);
                        }
                    }
                }
            }
        }

        // Detect negative cycles: check for further relaxations
        let queue_snapshot: Vec<u32> = (0..num_nodes as u32).collect();
        for u in queue_snapshot {
            let dist_u = self.dist[u as usize];

            for &edge_idx in graph.outgoing_edges(u) {
                let v = graph.edge_to(edge_idx);
                let symbol = graph.edge_symbol(edge_idx);
                let kind = graph.edge_kind(edge_idx);

                let ln_bid = ln_bids[symbol as usize];
                let ln_ask = ln_asks[symbol as usize];
                let w = compute_edge_weight(kind, ln_bid, ln_ask, self.k);

                let new_dist = dist_u + w;
                if new_dist < self.dist[v as usize] - 1e-12 {
                    // Found a node in a negative cycle
                    if let Some(cycle) =
                        self.extractor
                            .extract(v, &self.pred_node, &self.pred_edge, num_nodes)
                    {
                        let sig = canonicalize_cycle(cycle, graph);

                        // Check for duplicate
                        if !self.found_signatures.contains(&sig) {
                            self.found_signatures.push(sig);

                            // Compute profit
                            let mut total_weight = 0.0;
                            for &e in cycle {
                                let s = graph.edge_symbol(e);
                                let k = graph.edge_kind(e);
                                let w = compute_edge_weight(k, ln_bids[s as usize], ln_asks[s as usize], self.k);
                                total_weight += w;
                            }
                            let profit_bps = cycle_weight_to_profit_bps(total_weight);

                            candidates.push(CandidateCycle {
                                signature_id: sig,
                                edges: cycle.to_vec(),
                                profit_bps,
                            });

                            if candidates.len() >= self.max_candidates {
                                return candidates;
                            }
                        }
                    }
                }
            }
        }

        candidates
    }
}

/// Configuration for the cold BF discovery thread.
#[derive(Clone, Debug)]
pub struct ColdThreadConfig {
    /// Fee ln factor (k = ln(1 - fee))
    pub k: f64,
    /// Maximum cycle length to extract
    pub max_cycle_len: usize,
    /// Maximum number of candidate cycles
    pub max_candidates: usize,
    /// Discovery interval in milliseconds
    pub interval_ms: u64,
}

/// Cold BF discovery thread handle.
pub struct BfColdThread {
    /// Shared candidate set
    pub candidates: Arc<CandidateSet>,
    /// Shutdown flag
    shutdown: Arc<AtomicBool>,
    /// Thread handle
    handle: Option<thread::JoinHandle<()>>,
}

impl BfColdThread {
    /// Create a new cold BF thread (not started yet).
    pub fn new(max_candidates: usize) -> Self {
        Self {
            candidates: Arc::new(CandidateSet::new(max_candidates)),
            shutdown: Arc::new(AtomicBool::new(false)),
            handle: None,
        }
    }

    /// Get a clone of the candidate set Arc for hot path access.
    pub fn candidate_set(&self) -> Arc<CandidateSet> {
        Arc::clone(&self.candidates)
    }

    /// Start the cold BF discovery thread.
    pub fn start(
        config: ColdThreadConfig,
        graph: Arc<Graph>,
        price_store: Arc<PriceStore>,
    ) -> Self {
        let candidates = Arc::new(CandidateSet::new(config.max_candidates));
        let shutdown = Arc::new(AtomicBool::new(false));

        let candidates_clone = Arc::clone(&candidates);
        let shutdown_clone = Arc::clone(&shutdown);
        let interval = Duration::from_millis(config.interval_ms);
        let num_symbols = graph.num_edges / 2; // Approximate: each symbol creates 2 edges

        let handle = thread::spawn(move || {
            let mut bf = BfCold::new(
                graph.num_nodes as usize,
                config.k,
                config.max_cycle_len,
                config.max_candidates,
            );

            // Preallocate snapshot buffers
            let mut ln_bids = vec![0.0_f64; num_symbols as usize];
            let mut ln_asks = vec![0.0_f64; num_symbols as usize];

            while !shutdown_clone.load(Ordering::Acquire) {
                // Snapshot current prices
                for i in 0..num_symbols as usize {
                    ln_bids[i] = price_store.ln_bid(i as u32);
                    ln_asks[i] = price_store.ln_ask(i as u32);
                }

                // Run full discovery
                let discovered = bf.discover(&graph, &ln_bids, &ln_asks);

                // Publish to hot path
                if !discovered.is_empty() {
                    tracing::debug!("Cold BF discovered {} candidates", discovered.len());
                }
                candidates_clone.publish(discovered);

                // Sleep until next discovery
                thread::sleep(interval);
            }
        });

        Self {
            candidates,
            shutdown,
            handle: Some(handle),
        }
    }

    /// Stop the cold BF discovery thread.
    pub fn stop(mut self) {
        self.shutdown.store(true, Ordering::Release);
        if let Some(handle) = self.handle.take() {
            let _ = handle.join();
        }
    }
}

impl Drop for BfColdThread {
    fn drop(&mut self) {
        self.shutdown.store(true, Ordering::Release);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_candidate_set() {
        let set = CandidateSet::new(10);
        assert_eq!(set.count(), 0);
    }
}
