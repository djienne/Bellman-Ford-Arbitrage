//! Configuration loading and validation.

use anyhow::{Context, Result};
use serde::Deserialize;
use std::path::Path;

/// Main configuration struct.
#[derive(Debug, Clone, Deserialize)]
pub struct Config {
    /// Exchange to connect to (currently only "binance" supported)
    #[serde(default = "default_exchange")]
    pub exchange: String,

    /// Number of top base assets to select by 24h USDT volume.
    /// These assets will have their cross-pairs included for triangular arbitrage.
    #[serde(default = "default_top_pairs")]
    pub top_pairs: usize,

    /// Hub currencies that form the core of triangular arbitrage.
    /// All pairs between these hubs and top base assets will be included.
    /// Default: ["USDT", "BTC", "ETH", "BNB"]
    #[serde(default = "default_hub_assets")]
    pub hub_assets: Vec<String>,

    /// Quote asset filter (e.g., "USDT") - DEPRECATED, use hub_assets instead.
    /// If set, only pairs with this quote asset are included (disables triangular mode).
    #[serde(default)]
    pub quote_filter: Option<String>,

    /// Symbol blacklist patterns
    #[serde(default)]
    pub blacklist: Vec<String>,

    /// Trading fee in basis points (1 bp = 0.01%)
    #[serde(default = "default_fee_bps")]
    pub fee_bps: u16,

    /// Minimum profit threshold in basis points
    #[serde(default = "default_min_profit_bps")]
    pub min_profit_bps: u16,

    /// Price staleness threshold in nanoseconds
    #[serde(default = "default_stale_ns")]
    pub stale_ns: u64,

    /// Grace period for opportunity tracking in nanoseconds
    #[serde(default = "default_grace_ns")]
    pub grace_ns: u64,

    /// Interval for cold BF discovery in milliseconds
    #[serde(default = "default_bf_discovery_interval_ms")]
    pub bf_discovery_interval_ms: u64,

    /// Maximum relaxations per tick in hot BF
    #[serde(default = "default_max_relaxations_per_tick")]
    pub max_relaxations_per_tick: u32,

    /// Maximum cycle length to extract
    #[serde(default = "default_max_cycle_len")]
    pub max_cycle_len: usize,

    /// Maximum number of candidate cycles
    #[serde(default = "default_max_candidates")]
    pub max_candidates: usize,

    /// Ingestion ring buffer capacity
    #[serde(default = "default_ingestion_buffer_capacity")]
    pub ingestion_buffer_capacity: usize,

    /// Event ring buffer capacity
    #[serde(default = "default_event_buffer_capacity")]
    pub event_buffer_capacity: usize,

    /// Disable logging for minimum latency
    #[serde(default)]
    pub log_free: bool,
}

fn default_exchange() -> String {
    "binance".to_string()
}

fn default_top_pairs() -> usize {
    20 // Top 20 base assets by volume
}

fn default_hub_assets() -> Vec<String> {
    vec![
        "USDT".to_string(),
        "BTC".to_string(),
        "ETH".to_string(),
        "BNB".to_string(),
    ]
}

fn default_fee_bps() -> u16 {
    10 // 0.1%
}

fn default_min_profit_bps() -> u16 {
    5 // 0.05%
}

fn default_stale_ns() -> u64 {
    5_000_000_000 // 5 seconds
}

fn default_grace_ns() -> u64 {
    1_000_000_000 // 1 second
}

fn default_bf_discovery_interval_ms() -> u64 {
    10_000 // 10 seconds
}

fn default_max_relaxations_per_tick() -> u32 {
    500
}

fn default_max_cycle_len() -> usize {
    6
}

fn default_max_candidates() -> usize {
    100
}

fn default_ingestion_buffer_capacity() -> usize {
    4096
}

fn default_event_buffer_capacity() -> usize {
    1024
}

impl Config {
    /// Load configuration from a TOML file.
    pub fn load<P: AsRef<Path>>(path: P) -> Result<Self> {
        let content = std::fs::read_to_string(path.as_ref())
            .with_context(|| format!("Failed to read config file: {:?}", path.as_ref()))?;
        let config: Config =
            toml::from_str(&content).with_context(|| "Failed to parse config file")?;
        config.validate()?;
        Ok(config)
    }

    /// Create default configuration.
    pub fn default_config() -> Self {
        Self {
            exchange: default_exchange(),
            top_pairs: default_top_pairs(),
            hub_assets: default_hub_assets(),
            quote_filter: None, // Use hub_assets for triangular arbitrage
            blacklist: vec![],
            fee_bps: default_fee_bps(),
            min_profit_bps: default_min_profit_bps(),
            stale_ns: default_stale_ns(),
            grace_ns: default_grace_ns(),
            bf_discovery_interval_ms: default_bf_discovery_interval_ms(),
            max_relaxations_per_tick: default_max_relaxations_per_tick(),
            max_cycle_len: default_max_cycle_len(),
            max_candidates: default_max_candidates(),
            ingestion_buffer_capacity: default_ingestion_buffer_capacity(),
            event_buffer_capacity: default_event_buffer_capacity(),
            log_free: false,
        }
    }

    /// Validate configuration values.
    fn validate(&self) -> Result<()> {
        if self.top_pairs == 0 {
            anyhow::bail!("top_pairs must be > 0");
        }
        if self.fee_bps > 1000 {
            anyhow::bail!("fee_bps seems too high (> 10%)");
        }
        if self.max_cycle_len < 3 {
            anyhow::bail!("max_cycle_len must be >= 3");
        }
        if !self.ingestion_buffer_capacity.is_power_of_two() {
            anyhow::bail!("ingestion_buffer_capacity must be power of 2");
        }
        if !self.event_buffer_capacity.is_power_of_two() {
            anyhow::bail!("event_buffer_capacity must be power of 2");
        }
        Ok(())
    }

    /// Compute ln(1 - fee) for weight calculations.
    #[inline]
    pub fn fee_ln_factor(&self) -> f64 {
        let fee_ratio = self.fee_bps as f64 / 10_000.0;
        (1.0 - fee_ratio).ln()
    }

    /// Compute minimum profit threshold as a multiplier (1 + min_profit).
    #[inline]
    pub fn min_profit_threshold(&self) -> f64 {
        1.0 + (self.min_profit_bps as f64 / 10_000.0)
    }
}

impl Default for Config {
    fn default() -> Self {
        Self::default_config()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_default_config() {
        let config = Config::default();
        assert_eq!(config.top_pairs, 20);
        assert_eq!(config.fee_bps, 10);
        assert_eq!(config.hub_assets, vec!["USDT", "BTC", "ETH", "BNB"]);
    }

    #[test]
    fn test_fee_ln_factor() {
        let config = Config::default();
        let k = config.fee_ln_factor();
        // ln(0.999) ≈ -0.001
        assert!((k - (-0.001)).abs() < 0.0001);
    }
}
