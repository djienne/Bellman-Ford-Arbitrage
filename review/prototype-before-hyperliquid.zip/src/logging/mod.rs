//! Cold-path logging infrastructure.

mod logger;

pub use logger::LoggingThread;
