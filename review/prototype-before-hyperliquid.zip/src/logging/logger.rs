//! Cold-path logging thread.
//!
//! Consumes events from the hot path and formats them for output.
//! Also periodically logs statistics from the hot path.

use crate::ring_buffer::SpscRingBuffer;
use crate::stats::{HotPathStats, StatsSnapshot};
use crate::types::{ArbitrageEvent, ArbitrageEventKind};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use std::time::{Duration, Instant};

/// Interval for periodic stats logging.
const STATS_LOG_INTERVAL: Duration = Duration::from_secs(1);

/// Logging thread handle.
pub struct LoggingThread {
    /// Shutdown flag
    shutdown: Arc<AtomicBool>,
    /// Thread handle
    handle: Option<std::thread::JoinHandle<()>>,
}

impl LoggingThread {
    /// Start a new logging thread.
    ///
    /// # Arguments
    /// * `event_buffer` - Ring buffer to consume events from
    /// * `log_free` - If true, don't actually log (for benchmarking)
    pub fn start(
        event_buffer: Arc<SpscRingBuffer<ArbitrageEvent>>,
        log_free: bool,
    ) -> Self {
        Self::start_with_stats(event_buffer, None, log_free)
    }

    /// Start a new logging thread with stats reporting.
    ///
    /// # Arguments
    /// * `event_buffer` - Ring buffer to consume events from
    /// * `stats` - Optional hot-path stats to periodically report
    /// * `log_free` - If true, don't actually log (for benchmarking)
    pub fn start_with_stats(
        event_buffer: Arc<SpscRingBuffer<ArbitrageEvent>>,
        stats: Option<Arc<HotPathStats>>,
        log_free: bool,
    ) -> Self {
        let shutdown = Arc::new(AtomicBool::new(false));
        let shutdown_clone = Arc::clone(&shutdown);

        let handle = std::thread::spawn(move || {
            Self::run_loop(event_buffer, stats, shutdown_clone, log_free);
        });

        Self {
            shutdown,
            handle: Some(handle),
        }
    }

    /// Stop the logging thread.
    pub fn stop(mut self) {
        self.shutdown.store(true, Ordering::Release);
        if let Some(handle) = self.handle.take() {
            let _ = handle.join();
        }
    }

    /// Main loop for the logging thread.
    fn run_loop(
        buffer: Arc<SpscRingBuffer<ArbitrageEvent>>,
        stats: Option<Arc<HotPathStats>>,
        shutdown: Arc<AtomicBool>,
        log_free: bool,
    ) {
        let mut last_stats_time = Instant::now();
        let mut last_snapshot = StatsSnapshot::default();

        while !shutdown.load(Ordering::Acquire) {
            // Process all available events
            while let Some(event) = buffer.try_pop() {
                if !log_free {
                    Self::format_and_log(&event);
                }
            }

            // Periodic stats logging
            if let Some(ref stats) = stats {
                if last_stats_time.elapsed() >= STATS_LOG_INTERVAL {
                    let current = stats.snapshot();
                    let delta = current.delta(&last_snapshot);

                    if !log_free && delta.updates_processed > 0 {
                        tracing::info!(
                            "Stats: {} updates/s, {} cycles/s, total: {} updates, {} cycles",
                            delta.updates_processed,
                            delta.cycles_found,
                            current.updates_processed,
                            current.cycles_found
                        );
                    }

                    last_snapshot = current;
                    last_stats_time = Instant::now();
                }
            }

            // Sleep briefly to avoid busy spinning
            std::thread::sleep(Duration::from_micros(100));
        }

        // Drain remaining events
        while let Some(event) = buffer.try_pop() {
            if !log_free {
                Self::format_and_log(&event);
            }
        }
    }

    /// Format and log an event.
    fn format_and_log(event: &ArbitrageEvent) {
        let kind_str = match event.kind {
            ArbitrageEventKind::Started => "STARTED",
            ArbitrageEventKind::Updated => "UPDATED",
            ArbitrageEventKind::Ended => "ENDED  ",
        };

        let ts_secs = event.ts_ns as f64 / 1_000_000_000.0;

        match event.kind {
            ArbitrageEventKind::Started | ArbitrageEventKind::Updated => {
                println!(
                    "[{:.3}] {} sig={:016x} profit={:.2}bps",
                    ts_secs,
                    kind_str,
                    event.signature_id,
                    event.profit_bps as f64
                );
            }
            ArbitrageEventKind::Ended => {
                let duration_ms = event.duration_ns as f64 / 1_000_000.0;
                println!(
                    "[{:.3}] {} sig={:016x} duration={:.1}ms",
                    ts_secs, kind_str, event.signature_id, duration_ms
                );
            }
        }
    }
}

impl Drop for LoggingThread {
    fn drop(&mut self) {
        self.shutdown.store(true, Ordering::Release);
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::ring_buffer::OverflowPolicy;

    #[test]
    fn test_logging_thread_lifecycle() {
        let buffer: Arc<SpscRingBuffer<ArbitrageEvent>> =
            Arc::new(SpscRingBuffer::new(16, OverflowPolicy::DropNewest));

        // Start in log_free mode for testing
        let logger = LoggingThread::start(Arc::clone(&buffer), true);

        // Push some events
        buffer.try_push(ArbitrageEvent::started(12345, 10, 1000000000));
        buffer.try_push(ArbitrageEvent::updated(12345, 15, 2000000000));

        // Give thread time to process
        std::thread::sleep(std::time::Duration::from_millis(10));

        // Stop
        logger.stop();
    }
}
