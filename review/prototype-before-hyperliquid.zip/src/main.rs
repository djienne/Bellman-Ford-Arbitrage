//! Ultra-low-latency Bellman-Ford arbitrage detector.
//!
//! Main entry point and orchestration.

use anyhow::{Context, Result};
use bellman_arb::bellman_ford::cycle::{compute_cycle_weight, cycle_has_stale_edge, CycleExtractor};
use bellman_arb::bellman_ford::weights::cycle_weight_to_profit_bps;
use bellman_arb::bellman_ford::{BfColdThread, BfHot, ColdThreadConfig};
use bellman_arb::collectors::{create_collector, ExchangeCollector};
use bellman_arb::graph::GraphBuilder;
use bellman_arb::logging::LoggingThread;
use bellman_arb::ring_buffer::{OverflowPolicy, SpscRingBuffer};
use bellman_arb::state::PriceStore;
use bellman_arb::timing::OpportunityTracker;
use bellman_arb::types::{ArbitrageEvent, BestBidAskUpdate};
use bellman_arb::stats::HotPathStats;
use bellman_arb::Config;
use std::collections::HashMap;
use std::sync::Arc;
use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};
use tracing_subscriber::EnvFilter;

/// Timeout after which we switch to wall-clock time for expiration.
const WALL_CLOCK_FALLBACK_THRESHOLD: Duration = Duration::from_secs(1);

#[tokio::main]
async fn main() -> Result<()> {
    // Initialize logging
    tracing_subscriber::fmt()
        .with_env_filter(EnvFilter::from_default_env().add_directive("bellman_arb=info".parse()?))
        .init();

    // Load configuration
    let config_path = std::env::args()
        .nth(1)
        .unwrap_or_else(|| "config.toml".to_string());

    let config = if std::path::Path::new(&config_path).exists() {
        Config::load(&config_path).context("Failed to load configuration")?
    } else {
        tracing::warn!("Config file not found, using defaults");
        Config::default()
    };

    tracing::info!("Configuration loaded: {:?}", config);

    // Create collector and discover pairs
    let collector = create_collector(&config);
    let symbols = collector
        .discover_pairs(&config)
        .await
        .context("Failed to discover pairs")?;

    if symbols.is_empty() {
        anyhow::bail!("No symbols discovered");
    }

    tracing::info!("Discovered {} symbols", symbols.len());

    // Build graph
    let builder = GraphBuilder::new();
    let (graph, meta) = builder.build(&symbols);
    let graph = Arc::new(graph);

    tracing::info!(
        "Graph built: {} nodes (currencies), {} edges",
        graph.num_nodes,
        graph.num_edges
    );

    // Build symbol index map for collector
    let symbol_indices: HashMap<String, u32> = meta
        .symbol_to_index
        .iter()
        .map(|(k, v)| (k.clone(), *v))
        .collect();

    // Create price store
    let price_store = Arc::new(PriceStore::new(symbols.len()));

    // Create ring buffers
    let ingestion_buffer: Arc<SpscRingBuffer<BestBidAskUpdate>> = Arc::new(SpscRingBuffer::new(
        config.ingestion_buffer_capacity,
        OverflowPolicy::DropNewest,
    ));

    let event_buffer: Arc<SpscRingBuffer<ArbitrageEvent>> = Arc::new(SpscRingBuffer::new(
        config.event_buffer_capacity,
        OverflowPolicy::DropNewest,
    ));

    // Create hot-path stats (atomic counters)
    let stats = Arc::new(HotPathStats::new());

    // Start logging thread (if not log_free) with stats reporting
    let _logger = if !config.log_free {
        Some(LoggingThread::start_with_stats(
            Arc::clone(&event_buffer),
            Some(Arc::clone(&stats)),
            false,
        ))
    } else {
        None
    };

    // Start cold BF discovery thread
    let cold_config = ColdThreadConfig {
        k: config.fee_ln_factor(),
        max_cycle_len: config.max_cycle_len,
        max_candidates: config.max_candidates,
        interval_ms: config.bf_discovery_interval_ms,
    };
    let _cold_thread = BfColdThread::start(
        cold_config,
        Arc::clone(&graph),
        Arc::clone(&price_store),
    );
    tracing::info!(
        "Cold BF thread started (interval: {}ms)",
        config.bf_discovery_interval_ms
    );

    // Create BF hot state
    let k = config.fee_ln_factor();
    let mut bf_hot = BfHot::new(graph.num_nodes as usize, k, 256);

    // Create cycle extractor
    let mut extractor = CycleExtractor::new(config.max_cycle_len);

    // Create opportunity tracker
    let tracker = OpportunityTracker::new(128, config.min_profit_bps as u32);

    // Spawn collector streaming task
    let collector_symbols: Vec<String> = symbols.iter().map(|s| s.symbol.clone()).collect();
    let ingestion_buffer_clone = Arc::clone(&ingestion_buffer);

    tokio::spawn(async move {
        if let Err(e) = collector
            .start_streaming(collector_symbols, symbol_indices, ingestion_buffer_clone)
            .await
        {
            tracing::error!("Collector error: {:?}", e);
        }
    });

    tracing::info!("Starting hot-path loop...");

    // Hot-path main loop
    let mut last_ts_ns = 0u64;
    let mut last_update_instant = Instant::now();

    loop {
        // Track if we received any updates this tick
        let mut received_update = false;

        // Drain ingestion buffer
        while let Some(update) = ingestion_buffer.try_pop() {
            received_update = true;
            // Update price store (using pre-computed ln values)
            price_store.update_precomputed(
                update.symbol_index,
                update.bid(),
                update.ask(),
                update.ln_bid(),
                update.ln_ask(),
                update.ts_ns,
            );

            // Notify BF of price change
            bf_hot.on_price_update(update.symbol_index, &graph);

            // Track latest timestamp
            if update.ts_ns > last_ts_ns {
                last_ts_ns = update.ts_ns;
            }

            // Atomic increment (no logging in hot path)
            stats.inc_updates();
        }

        // Update last_update_instant if we received updates
        if received_update {
            last_update_instant = Instant::now();
        }

        // Run budgeted BF relaxation
        if let Some(cycle_node) = bf_hot.relax_budget(
            config.max_relaxations_per_tick,
            &graph,
            &price_store,
        ) {
            // Extract cycle
            let (pred_node, pred_edge) = bf_hot.predecessors();
            if let Some(cycle_edges) = extractor.extract(
                cycle_node,
                pred_node,
                pred_edge,
                graph.num_nodes as usize,
            ) {
                // Skip cycles with stale price data
                if cycle_has_stale_edge(
                    cycle_edges,
                    &graph,
                    &price_store,
                    last_ts_ns,
                    config.stale_ns,
                ) {
                    continue;
                }

                // Compute signature using free function (avoids double borrow)
                let signature = bellman_arb::bellman_ford::canonicalize_cycle(cycle_edges, &graph);

                // Compute current profit
                let total_weight = compute_cycle_weight(cycle_edges, &graph, &price_store, k);
                let profit_bps = cycle_weight_to_profit_bps(total_weight);

                // Update tracker
                tracker.update(
                    signature,
                    profit_bps,
                    last_ts_ns,
                    Some(&event_buffer),
                );

                // Atomic increment (no logging in hot path)
                stats.inc_cycles();
            }
        }

        // Check for expired opportunities
        // Use wall-clock time if we haven't received updates recently (disconnect handling)
        let expiration_ts_ns = if last_update_instant.elapsed() > WALL_CLOCK_FALLBACK_THRESHOLD {
            SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .map(|d| d.as_nanos() as u64)
                .unwrap_or(last_ts_ns)
        } else {
            last_ts_ns
        };
        tracker.expire_stale(expiration_ts_ns, config.grace_ns, Some(&event_buffer));

        // Brief yield to prevent busy spinning when buffer is empty
        if ingestion_buffer.is_empty() {
            std::hint::spin_loop();
        }
    }
}
