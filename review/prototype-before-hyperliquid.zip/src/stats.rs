//! Hot-path statistics with atomic counters.
//!
//! Provides zero-overhead statistics collection using atomics.
//! The logging thread periodically reads and reports these stats.

use std::sync::atomic::{AtomicU64, Ordering};

/// Hot-path statistics counters.
/// All operations are lock-free using atomic increments.
pub struct HotPathStats {
    /// Total updates processed from ingestion buffer
    updates_processed: AtomicU64,
    /// Total negative cycles found
    cycles_found: AtomicU64,
    /// Total relaxations performed
    relaxations: AtomicU64,
}

impl HotPathStats {
    /// Create a new stats instance.
    pub const fn new() -> Self {
        Self {
            updates_processed: AtomicU64::new(0),
            cycles_found: AtomicU64::new(0),
            relaxations: AtomicU64::new(0),
        }
    }

    /// Increment updates processed counter.
    #[inline(always)]
    pub fn inc_updates(&self) {
        self.updates_processed.fetch_add(1, Ordering::Relaxed);
    }

    /// Increment cycles found counter.
    #[inline(always)]
    pub fn inc_cycles(&self) {
        self.cycles_found.fetch_add(1, Ordering::Relaxed);
    }

    /// Increment relaxations counter.
    #[inline(always)]
    pub fn add_relaxations(&self, count: u64) {
        self.relaxations.fetch_add(count, Ordering::Relaxed);
    }

    /// Get current updates processed count.
    #[inline]
    pub fn updates_processed(&self) -> u64 {
        self.updates_processed.load(Ordering::Relaxed)
    }

    /// Get current cycles found count.
    #[inline]
    pub fn cycles_found(&self) -> u64 {
        self.cycles_found.load(Ordering::Relaxed)
    }

    /// Get current relaxations count.
    #[inline]
    pub fn relaxations(&self) -> u64 {
        self.relaxations.load(Ordering::Relaxed)
    }

    /// Take a snapshot of current stats (for delta computation).
    #[inline]
    pub fn snapshot(&self) -> StatsSnapshot {
        StatsSnapshot {
            updates_processed: self.updates_processed(),
            cycles_found: self.cycles_found(),
            relaxations: self.relaxations(),
        }
    }
}

impl Default for HotPathStats {
    fn default() -> Self {
        Self::new()
    }
}

/// Snapshot of stats at a point in time.
#[derive(Clone, Copy, Debug, Default)]
pub struct StatsSnapshot {
    pub updates_processed: u64,
    pub cycles_found: u64,
    pub relaxations: u64,
}

impl StatsSnapshot {
    /// Compute delta from a previous snapshot.
    pub fn delta(&self, prev: &StatsSnapshot) -> StatsSnapshot {
        StatsSnapshot {
            updates_processed: self.updates_processed.saturating_sub(prev.updates_processed),
            cycles_found: self.cycles_found.saturating_sub(prev.cycles_found),
            relaxations: self.relaxations.saturating_sub(prev.relaxations),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_stats_increment() {
        let stats = HotPathStats::new();

        stats.inc_updates();
        stats.inc_updates();
        stats.inc_cycles();
        stats.add_relaxations(100);

        assert_eq!(stats.updates_processed(), 2);
        assert_eq!(stats.cycles_found(), 1);
        assert_eq!(stats.relaxations(), 100);
    }

    #[test]
    fn test_snapshot_delta() {
        let stats = HotPathStats::new();
        stats.inc_updates();
        let snap1 = stats.snapshot();

        stats.inc_updates();
        stats.inc_updates();
        let snap2 = stats.snapshot();

        let delta = snap2.delta(&snap1);
        assert_eq!(delta.updates_processed, 2);
    }
}
