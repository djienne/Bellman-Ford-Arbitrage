//! Exchange collector abstraction and implementations.
//!
//! This module provides a trait-based abstraction for exchange collectors,
//! allowing new exchanges to be added without modifying the hot path.

mod binance;

pub use binance::BinanceCollector;

use crate::{Config, SymbolMeta};
use anyhow::Result;
use std::collections::HashMap;
use std::sync::Arc;

/// Trait for exchange collectors.
///
/// Implementations must:
/// - Discover tradable pairs via REST API
/// - Stream best bid/ask via WebSocket
/// - Handle reconnection automatically
///
/// Note: We use async_trait to enable async methods in traits.
#[async_trait::async_trait]
pub trait ExchangeCollector: Send + Sync {
    /// Discover pairs from the exchange and return metadata.
    async fn discover_pairs(&self, config: &Config) -> Result<Vec<SymbolMeta>>;

    /// Start streaming best bid/ask updates.
    /// This should run indefinitely with automatic reconnection.
    async fn start_streaming(
        &self,
        symbols: Vec<String>,
        symbol_indices: HashMap<String, u32>,
        buffer: Arc<crate::ring_buffer::SpscRingBuffer<crate::BestBidAskUpdate>>,
    ) -> Result<()>;
}

/// Create the appropriate collector based on configuration.
/// Returns a boxed collector that can be used polymorphically.
pub fn create_collector(config: &Config) -> BinanceCollector {
    match config.exchange.as_str() {
        "binance" => BinanceCollector::new(),
        _ => panic!("Unsupported exchange: {}", config.exchange),
    }
}
