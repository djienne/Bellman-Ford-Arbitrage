//! Binance exchange collector implementation.
//!
//! Handles REST API discovery of top pairs and WebSocket streaming
//! of best bid/ask updates.

use crate::collectors::ExchangeCollector;
use crate::ring_buffer::SpscRingBuffer;
use crate::types::{BestBidAskUpdate, SymbolMeta};
use crate::Config;
use anyhow::{Context, Result};
use futures_util::{SinkExt, StreamExt};
use serde::de::DeserializeOwned;
use serde::Deserialize;
use std::collections::HashMap;
use std::sync::Arc;
use std::time::Duration;
use tokio_tungstenite::{connect_async, tungstenite::Message};

const BINANCE_REST_BASE: &str = "https://api.binance.com";
const BINANCE_WS_BASE: &str = "wss://stream.binance.com:9443";

/// Exponential backoff configuration.
struct ExponentialBackoff {
    /// Base delay in milliseconds
    base_ms: u64,
    /// Maximum delay in milliseconds
    max_ms: u64,
    /// Current attempt count
    attempts: u32,
}

impl ExponentialBackoff {
    fn new(base_ms: u64, max_ms: u64) -> Self {
        Self {
            base_ms,
            max_ms,
            attempts: 0,
        }
    }

    /// Get the next backoff duration with jitter.
    fn next_backoff(&mut self) -> Duration {
        let delay_ms = self.base_ms.saturating_mul(1 << self.attempts.min(10));
        let delay_ms = delay_ms.min(self.max_ms);

        // Add 25% jitter
        let jitter = (delay_ms as f64 * 0.25 * rand_jitter()) as u64;
        let final_delay = delay_ms.saturating_add(jitter);

        self.attempts = self.attempts.saturating_add(1);
        Duration::from_millis(final_delay)
    }

    /// Reset backoff after successful connection.
    fn reset(&mut self) {
        self.attempts = 0;
    }
}

/// Simple pseudo-random jitter factor (0.0 to 1.0).
/// Uses time-based seeding for simplicity (no external dependencies).
fn rand_jitter() -> f64 {
    use std::time::SystemTime;
    let nanos = SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.subsec_nanos())
        .unwrap_or(0);
    (nanos as f64 / u32::MAX as f64).fract()
}

/// Binance symbol info from REST API.
#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
struct BinanceSymbol {
    symbol: String,
    status: String,
    base_asset: String,
    quote_asset: String,
}

/// Binance exchange info response.
#[derive(Debug, Deserialize)]
struct ExchangeInfo {
    symbols: Vec<BinanceSymbol>,
}

/// Binance 24h ticker.
#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
struct Ticker24h {
    symbol: String,
    quote_volume: String,
}

/// Binance bookTicker WebSocket message.
#[derive(Debug, Deserialize)]
#[allow(non_snake_case)]
struct BookTicker {
    s: String, // Symbol
    b: String, // Best bid price
    a: String, // Best ask price
    #[serde(default)]
    E: u64, // Event time - not in documented bookTicker payload, always 0. Falls back to system time.
}

/// Combined stream wrapper message.
/// Avoids DOM parsing by deserializing directly.
#[derive(Debug, Deserialize)]
struct StreamMessage {
    #[allow(dead_code)]
    stream: String,
    data: BookTicker,
}

/// Binance collector.
pub struct BinanceCollector {
    client: reqwest::Client,
}

impl BinanceCollector {
    /// Create a new Binance collector.
    pub fn new() -> Self {
        Self {
            client: reqwest::Client::builder()
                .timeout(Duration::from_secs(30))
                .build()
                .expect("Failed to create HTTP client"),
        }
    }

    /// Fetch with retry logic and rate limit handling.
    ///
    /// Handles HTTP 429 (rate limit) and 418 (IP ban) responses by respecting
    /// the Retry-After header. Other errors use exponential backoff.
    async fn fetch_with_retry<T: DeserializeOwned>(&self, url: &str) -> Result<T> {
        let mut backoff = ExponentialBackoff::new(1000, 60000);

        loop {
            let resp = self
                .client
                .get(url)
                .send()
                .await
                .context("HTTP request failed")?;

            match resp.status().as_u16() {
                200 => {
                    return resp.json().await.context("Failed to parse response");
                }
                429 | 418 => {
                    // Rate limited or IP banned - respect Retry-After header
                    let wait_secs = resp
                        .headers()
                        .get("Retry-After")
                        .and_then(|v| v.to_str().ok())
                        .and_then(|s| s.parse::<u64>().ok())
                        .unwrap_or(60);

                    tracing::warn!(
                        "Rate limited (HTTP {}), waiting {}s (Retry-After)",
                        resp.status(),
                        wait_secs
                    );
                    tokio::time::sleep(Duration::from_secs(wait_secs)).await;
                    backoff.reset(); // Reset backoff after rate limit wait
                }
                status => {
                    let delay = backoff.next_backoff();
                    tracing::warn!(
                        "HTTP {} for {}, retrying in {:.1}s",
                        status,
                        url,
                        delay.as_secs_f64()
                    );
                    tokio::time::sleep(delay).await;
                }
            }
        }
    }

    /// Fetch exchange info.
    async fn fetch_exchange_info(&self) -> Result<ExchangeInfo> {
        let url = format!("{}/api/v3/exchangeInfo", BINANCE_REST_BASE);
        self.fetch_with_retry(&url).await
    }

    /// Fetch 24h tickers for volume ranking.
    async fn fetch_24h_tickers(&self) -> Result<Vec<Ticker24h>> {
        let url = format!("{}/api/v3/ticker/24hr", BINANCE_REST_BASE);
        self.fetch_with_retry(&url).await
    }
}

impl Default for BinanceCollector {
    fn default() -> Self {
        Self::new()
    }
}

#[async_trait::async_trait]
impl ExchangeCollector for BinanceCollector {
    async fn discover_pairs(&self, config: &Config) -> Result<Vec<SymbolMeta>> {
        tracing::info!("Discovering Binance pairs...");

        // Fetch exchange info and 24h tickers in parallel
        let (info, tickers) = tokio::try_join!(self.fetch_exchange_info(), self.fetch_24h_tickers())?;

        // Build volume map by symbol
        let volume_map: HashMap<String, f64> = tickers
            .into_iter()
            .filter_map(|t| {
                let vol: f64 = t.quote_volume.parse().ok()?;
                Some((t.symbol, vol))
            })
            .collect();

        // If quote_filter is set (legacy mode), use simple filtering
        if let Some(ref quote_filter) = config.quote_filter {
            return self.discover_pairs_legacy(&info, &volume_map, config, quote_filter);
        }

        // Triangular arbitrage mode: select pairs that form triangles via hub currencies
        self.discover_pairs_triangular(&info, &volume_map, config)
    }

    async fn start_streaming(
        &self,
        symbols: Vec<String>,
        symbol_indices: HashMap<String, u32>,
        buffer: Arc<SpscRingBuffer<BestBidAskUpdate>>,
    ) -> Result<()> {
        // Binance WebSocket limit: max 1024 streams per connection
        if symbols.len() > 1024 {
            anyhow::bail!(
                "Binance WS limit exceeded: {} streams requested, max 1024",
                symbols.len()
            );
        }

        // Exponential backoff: 1s base, 60s max, 25% jitter
        let mut backoff = ExponentialBackoff::new(1000, 60000);

        loop {
            match self
                .stream_with_reconnect(&symbols, &symbol_indices, &buffer)
                .await
            {
                Ok(()) => {
                    // Connection was established and then closed normally
                    backoff.reset();
                }
                Err(e) => {
                    let delay = backoff.next_backoff();
                    tracing::error!(
                        "WebSocket error: {:?}, reconnecting in {:.1}s...",
                        e,
                        delay.as_secs_f64()
                    );
                    tokio::time::sleep(delay).await;
                }
            }
        }
    }
}

impl BinanceCollector {
    /// Stream with automatic reconnection.
    ///
    /// Uses a unified `tokio::select!` loop to handle both incoming messages and
    /// keepalive pongs. This is required because `split()` decouples read/write,
    /// preventing automatic Pong responses to server Pings.
    async fn stream_with_reconnect(
        &self,
        symbols: &[String],
        symbol_indices: &HashMap<String, u32>,
        buffer: &Arc<SpscRingBuffer<BestBidAskUpdate>>,
    ) -> Result<()> {
        // Build combined stream URL
        // Format: wss://stream.binance.com:9443/stream?streams=btcusdt@bookTicker/ethusdt@bookTicker/...
        let streams: Vec<String> = symbols
            .iter()
            .map(|s| format!("{}@bookTicker", s.to_lowercase()))
            .collect();

        let url = format!("{}/stream?streams={}", BINANCE_WS_BASE, streams.join("/"));

        tracing::info!("Connecting to Binance WebSocket...");
        let (mut ws_stream, _) = connect_async(&url)
            .await
            .context("Failed to connect to WebSocket")?;

        tracing::info!("WebSocket connected, streaming {} symbols", symbols.len());

        // Keepalive interval: send unsolicited pong every 30s (per Binance docs, empty payload)
        let mut keepalive_interval = tokio::time::interval(Duration::from_secs(30));

        loop {
            tokio::select! {
                msg = ws_stream.next() => {
                    match msg {
                        Some(Ok(Message::Text(text))) => {
                            // Parse combined stream wrapper directly
                            // Format: {"stream":"btcusdt@bookTicker","data":{...}}
                            if let Ok(msg) = serde_json::from_str::<StreamMessage>(&text) {
                                self.process_ticker(&msg.data, symbol_indices, buffer);
                            }
                        }
                        Some(Ok(Message::Ping(data))) => {
                            // CRITICAL: Respond with pong immediately using same payload
                            // Binance disconnects if no pong received within 60s of ping
                            tracing::trace!("Received ping, sending pong");
                            ws_stream.send(Message::Pong(data)).await
                                .context("Failed to send pong")?;
                        }
                        Some(Ok(Message::Close(frame))) => {
                            tracing::warn!("WebSocket closed by server: {:?}", frame);
                            break;
                        }
                        Some(Ok(_)) => {
                            // Ignore other message types (Pong, Binary, Frame)
                        }
                        Some(Err(e)) => {
                            return Err(e).context("WebSocket read error");
                        }
                        None => {
                            // Stream ended
                            break;
                        }
                    }
                }
                _ = keepalive_interval.tick() => {
                    // Send unsolicited pong as keepalive (empty payload per Binance docs)
                    tracing::trace!("Sending keepalive pong");
                    ws_stream.send(Message::Pong(vec![])).await
                        .context("Failed to send keepalive pong")?;
                }
            }
        }

        Err(anyhow::anyhow!("WebSocket stream ended"))
    }

    /// Process a bookTicker message.
    fn process_ticker(
        &self,
        ticker: &BookTicker,
        symbol_indices: &HashMap<String, u32>,
        buffer: &Arc<SpscRingBuffer<BestBidAskUpdate>>,
    ) {
        // Look up symbol index
        let Some(&index) = symbol_indices.get(&ticker.s) else {
            return;
        };

        // Parse bid/ask
        let Ok(bid) = ticker.b.parse::<f64>() else {
            return;
        };
        let Ok(ask) = ticker.a.parse::<f64>() else {
            return;
        };

        // Get timestamp (use event time if available, otherwise system time)
        let ts_ns = if ticker.E > 0 {
            ticker.E * 1_000_000 // Convert ms to ns
        } else {
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .map(|d| d.as_nanos() as u64)
                .unwrap_or(0)
        };

        // Push to buffer
        let update = BestBidAskUpdate::new(index, bid, ask, ts_ns);
        let _ = buffer.try_push(update); // Drop if full (policy enforced by buffer)
    }

    /// Legacy pair discovery: filter by single quote asset.
    fn discover_pairs_legacy(
        &self,
        info: &ExchangeInfo,
        volume_map: &HashMap<String, f64>,
        config: &Config,
        quote_filter: &str,
    ) -> Result<Vec<SymbolMeta>> {
        let mut candidates: Vec<SymbolMeta> = info
            .symbols
            .iter()
            .filter(|s| {
                s.status == "TRADING"
                    && s.quote_asset == quote_filter
                    && !config.blacklist.iter().any(|p| s.symbol.contains(p))
                    && volume_map.contains_key(&s.symbol)
            })
            .map(|s| {
                let vol = volume_map.get(&s.symbol).copied().unwrap_or(0.0);
                SymbolMeta {
                    symbol: s.symbol.clone(),
                    base_asset: s.base_asset.clone(),
                    quote_asset: s.quote_asset.clone(),
                    quote_volume_24h: vol,
                }
            })
            .collect();

        candidates.sort_by(|a, b| {
            b.quote_volume_24h
                .partial_cmp(&a.quote_volume_24h)
                .unwrap_or(std::cmp::Ordering::Equal)
        });
        candidates.truncate(config.top_pairs);

        tracing::info!("Discovered {} pairs (legacy mode)", candidates.len());
        Ok(candidates)
    }

    /// Triangular arbitrage pair discovery.
    ///
    /// Strategy:
    /// 1. Select top N base assets by USDT volume (these are the most liquid)
    /// 2. For each base asset, include all available pairs with hub currencies
    /// 3. Also include pairs between hub currencies themselves
    ///
    /// Example with hubs=[USDT, BTC, ETH] and top_pairs=3 selecting [SOL, XRP, DOGE]:
    /// - Hub pairs: BTCUSDT, ETHUSDT, ETHBTC
    /// - SOL pairs: SOLUSDT, SOLBTC, SOLETH (if available)
    /// - XRP pairs: XRPUSDT, XRPBTC, XRPETH (if available)
    /// - DOGE pairs: DOGEUSDT, DOGEBTC (DOGEETH may not exist)
    fn discover_pairs_triangular(
        &self,
        info: &ExchangeInfo,
        volume_map: &HashMap<String, f64>,
        config: &Config,
    ) -> Result<Vec<SymbolMeta>> {
        use std::collections::HashSet;

        let hub_set: HashSet<&str> = config.hub_assets.iter().map(|s| s.as_str()).collect();

        // Build a map: (base, quote) -> BinanceSymbol for quick lookup
        let mut pair_map: HashMap<(&str, &str), &BinanceSymbol> = HashMap::new();
        for sym in &info.symbols {
            if sym.status == "TRADING" && !config.blacklist.iter().any(|p| sym.symbol.contains(p)) {
                pair_map.insert((&sym.base_asset, &sym.quote_asset), sym);
            }
        }

        // Step 1: Rank base assets by USDT volume (most universal hub)
        let mut base_volumes: Vec<(&str, f64)> = info
            .symbols
            .iter()
            .filter(|s| s.status == "TRADING" && s.quote_asset == "USDT")
            .filter_map(|s| {
                let vol = volume_map.get(&s.symbol)?;
                Some((s.base_asset.as_str(), *vol))
            })
            .collect();

        base_volumes.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal));

        // Step 2: Select top N base assets (excluding hubs themselves, they're added separately)
        let selected_bases: Vec<&str> = base_volumes
            .iter()
            .filter(|(base, _)| !hub_set.contains(base))
            .take(config.top_pairs)
            .map(|(base, _)| *base)
            .collect();

        tracing::debug!("Selected base assets: {:?}", selected_bases);

        // Step 3: Collect all pairs
        let mut result: Vec<SymbolMeta> = Vec::new();
        let mut added: HashSet<String> = HashSet::new();

        // Helper to add a pair if it exists
        let mut add_pair = |base: &str, quote: &str| {
            if let Some(sym) = pair_map.get(&(base, quote)) {
                if !added.contains(&sym.symbol) {
                    let vol = volume_map.get(&sym.symbol).copied().unwrap_or(0.0);
                    result.push(SymbolMeta {
                        symbol: sym.symbol.clone(),
                        base_asset: sym.base_asset.clone(),
                        quote_asset: sym.quote_asset.clone(),
                        quote_volume_24h: vol,
                    });
                    added.insert(sym.symbol.clone());
                }
            }
        };

        // Add pairs between hub currencies (e.g., BTCUSDT, ETHUSDT, ETHBTC, BNBUSDT, BNBBTC, BNBETH)
        let hubs: Vec<&str> = config.hub_assets.iter().map(|s| s.as_str()).collect();
        for i in 0..hubs.len() {
            for j in 0..hubs.len() {
                if i != j {
                    add_pair(hubs[i], hubs[j]);
                }
            }
        }

        // Add pairs for each selected base asset with all hubs
        for base in &selected_bases {
            for hub in &hubs {
                if *base != *hub {
                    add_pair(base, hub);
                }
            }
        }

        // Sort by volume for consistency
        result.sort_by(|a, b| {
            b.quote_volume_24h
                .partial_cmp(&a.quote_volume_24h)
                .unwrap_or(std::cmp::Ordering::Equal)
        });

        tracing::info!(
            "Discovered {} pairs for triangular arbitrage ({} base assets + {} hubs)",
            result.len(),
            selected_bases.len(),
            config.hub_assets.len()
        );

        Ok(result)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_book_ticker_parse() {
        let json = r#"{"s":"BTCUSDT","b":"40000.00","a":"40001.00","E":1234567890123}"#;
        let ticker: BookTicker = serde_json::from_str(json).unwrap();
        assert_eq!(ticker.s, "BTCUSDT");
        assert_eq!(ticker.b, "40000.00");
        assert_eq!(ticker.a, "40001.00");
    }
}
