//! Ultra-low-latency Bellman-Ford arbitrage detector.
//!
//! This library provides a high-performance system for detecting arbitrage
//! opportunities in cryptocurrency markets using Bellman-Ford negative cycle
//! detection.
//!
//! # Architecture
//!
//! The system is divided into hot path and cold path components:
//!
//! ## Hot Path (Latency-Critical)
//! - No locks, no allocations after init, no logging
//! - Incremental budgeted Bellman-Ford relaxation
//! - Lock-free atomic price state
//! - Zero-copy ring buffers
//!
//! ## Cold Path
//! - Exchange WebSocket/REST handling
//! - Full Bellman-Ford discovery
//! - Logging and event formatting

pub mod bellman_ford;
pub mod collectors;
pub mod config;
pub mod graph;
pub mod logging;
pub mod ring_buffer;
pub mod state;
pub mod stats;
pub mod timing;
pub mod types;

pub use config::Config;
pub use stats::HotPathStats;
pub use types::{ArbitrageEvent, ArbitrageEventKind, BestBidAskUpdate, SymbolMeta};
