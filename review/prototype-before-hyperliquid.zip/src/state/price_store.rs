//! Atomic price store for hot-path access.
//!
//! Each symbol's best bid/ask is stored with precomputed ln values
//! to avoid log() calls in the hot path.

use std::sync::atomic::{AtomicU64, Ordering};

/// Per-symbol atomic state, cache-line aligned to prevent false sharing.
#[repr(C, align(64))]
pub struct SymbolState {
    /// Best bid price (f64 bits)
    bid_bits: AtomicU64,
    /// Best ask price (f64 bits)
    ask_bits: AtomicU64,
    /// Timestamp of last update (nanoseconds)
    ts_ns: AtomicU64,
    /// ln(bid) precomputed (f64 bits)
    ln_bid_bits: AtomicU64,
    /// ln(ask) precomputed (f64 bits)
    ln_ask_bits: AtomicU64,
    /// Padding to fill cache line
    _pad: [u64; 3],
}

impl Default for SymbolState {
    fn default() -> Self {
        Self {
            bid_bits: AtomicU64::new(0),
            ask_bits: AtomicU64::new(0),
            ts_ns: AtomicU64::new(0),
            ln_bid_bits: AtomicU64::new(f64::NEG_INFINITY.to_bits()),
            ln_ask_bits: AtomicU64::new(f64::INFINITY.to_bits()),
            _pad: [0; 3],
        }
    }
}

impl SymbolState {
    /// Update bid/ask and precompute ln values.
    /// Note: Prefer `update_precomputed()` for hot-path usage.
    #[inline]
    pub fn update(&self, bid: f64, ask: f64, ts_ns: u64) {
        // Compute ln values (this happens on the producer side, not hot path)
        let ln_bid = if bid > 0.0 { bid.ln() } else { f64::NEG_INFINITY };
        let ln_ask = if ask > 0.0 { ask.ln() } else { f64::INFINITY };

        self.update_precomputed(bid, ask, ln_bid, ln_ask, ts_ns);
    }

    /// Update bid/ask with pre-computed ln values.
    /// This is the hot-path version that skips ln() calls.
    #[inline(always)]
    pub fn update_precomputed(&self, bid: f64, ask: f64, ln_bid: f64, ln_ask: f64, ts_ns: u64) {
        // Store all values atomically
        // Order matters for consumers: update ln values first, then prices, then timestamp
        self.ln_bid_bits.store(ln_bid.to_bits(), Ordering::Release);
        self.ln_ask_bits.store(ln_ask.to_bits(), Ordering::Release);
        self.bid_bits.store(bid.to_bits(), Ordering::Release);
        self.ask_bits.store(ask.to_bits(), Ordering::Release);
        self.ts_ns.store(ts_ns, Ordering::Release);
    }

    /// Get the best bid price.
    #[inline(always)]
    pub fn bid(&self) -> f64 {
        f64::from_bits(self.bid_bits.load(Ordering::Acquire))
    }

    /// Get the best ask price.
    #[inline(always)]
    pub fn ask(&self) -> f64 {
        f64::from_bits(self.ask_bits.load(Ordering::Acquire))
    }

    /// Get ln(bid) for weight computation.
    #[inline(always)]
    pub fn ln_bid(&self) -> f64 {
        f64::from_bits(self.ln_bid_bits.load(Ordering::Acquire))
    }

    /// Get ln(ask) for weight computation.
    #[inline(always)]
    pub fn ln_ask(&self) -> f64 {
        f64::from_bits(self.ln_ask_bits.load(Ordering::Acquire))
    }

    /// Get the timestamp of the last update.
    #[inline(always)]
    pub fn ts_ns(&self) -> u64 {
        self.ts_ns.load(Ordering::Acquire)
    }

    /// Check if data is valid (non-zero bid/ask).
    #[inline(always)]
    pub fn is_valid(&self) -> bool {
        let bid = self.bid();
        let ask = self.ask();
        bid > 0.0 && ask > 0.0 && ask >= bid
    }
}

/// Atomic price store holding state for all symbols.
pub struct PriceStore {
    /// Per-symbol state (fixed size, preallocated)
    symbols: Box<[SymbolState]>,
    /// Number of symbols
    num_symbols: usize,
}

impl PriceStore {
    /// Create a new price store for the given number of symbols.
    pub fn new(num_symbols: usize) -> Self {
        let mut symbols = Vec::with_capacity(num_symbols);
        for _ in 0..num_symbols {
            symbols.push(SymbolState::default());
        }
        Self {
            symbols: symbols.into_boxed_slice(),
            num_symbols,
        }
    }

    /// Get the number of symbols.
    #[inline]
    pub fn num_symbols(&self) -> usize {
        self.num_symbols
    }

    /// Update a symbol's bid/ask.
    #[inline]
    pub fn update(&self, symbol_index: u32, bid: f64, ask: f64, ts_ns: u64) {
        debug_assert!((symbol_index as usize) < self.num_symbols);
        self.symbols[symbol_index as usize].update(bid, ask, ts_ns);
    }

    /// Update a symbol's bid/ask with pre-computed ln values.
    /// This is the hot-path version that skips ln() calls.
    #[inline(always)]
    pub fn update_precomputed(
        &self,
        symbol_index: u32,
        bid: f64,
        ask: f64,
        ln_bid: f64,
        ln_ask: f64,
        ts_ns: u64,
    ) {
        debug_assert!((symbol_index as usize) < self.num_symbols);
        self.symbols[symbol_index as usize].update_precomputed(bid, ask, ln_bid, ln_ask, ts_ns);
    }

    /// Get a symbol's state.
    #[inline(always)]
    pub fn get(&self, symbol_index: u32) -> &SymbolState {
        debug_assert!((symbol_index as usize) < self.num_symbols);
        &self.symbols[symbol_index as usize]
    }

    /// Get ln(bid) for a symbol.
    #[inline(always)]
    pub fn ln_bid(&self, symbol_index: u32) -> f64 {
        self.get(symbol_index).ln_bid()
    }

    /// Get ln(ask) for a symbol.
    #[inline(always)]
    pub fn ln_ask(&self, symbol_index: u32) -> f64 {
        self.get(symbol_index).ln_ask()
    }

    /// Check if a symbol's data is stale relative to the given timestamp.
    #[inline]
    pub fn is_stale(&self, symbol_index: u32, now_ns: u64, stale_threshold_ns: u64) -> bool {
        let ts = self.get(symbol_index).ts_ns();
        ts == 0 || now_ns.saturating_sub(ts) > stale_threshold_ns
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_symbol_state_update() {
        let state = SymbolState::default();

        state.update(100.0, 101.0, 1000);

        assert!((state.bid() - 100.0).abs() < 1e-10);
        assert!((state.ask() - 101.0).abs() < 1e-10);
        assert_eq!(state.ts_ns(), 1000);
        assert!((state.ln_bid() - 100.0_f64.ln()).abs() < 1e-10);
        assert!((state.ln_ask() - 101.0_f64.ln()).abs() < 1e-10);
    }

    #[test]
    fn test_price_store() {
        let store = PriceStore::new(10);

        store.update(5, 50.0, 51.0, 2000);

        assert!((store.get(5).bid() - 50.0).abs() < 1e-10);
        assert!(!store.is_stale(5, 2500, 1000));
        assert!(store.is_stale(5, 4000, 1000));
    }

    #[test]
    fn test_cache_line_alignment() {
        // Verify SymbolState is 64 bytes (one cache line)
        assert_eq!(std::mem::size_of::<SymbolState>(), 64);
    }
}
