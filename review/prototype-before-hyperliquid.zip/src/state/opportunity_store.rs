//! Lock-free opportunity tracking store.
//!
//! Tracks active arbitrage opportunities with timing information,
//! using a fixed-size hash table with linear probing.

use std::sync::atomic::{AtomicU64, AtomicU8, Ordering};

/// State of an opportunity slot.
const SLOT_EMPTY: u8 = 0;
const SLOT_ACTIVE: u8 = 1;
const SLOT_INACTIVE: u8 = 2;

/// Per-opportunity tracking slot, cache-line aligned.
#[repr(C, align(64))]
pub struct OpportunitySlot {
    /// Canonical cycle signature
    signature_id: AtomicU64,
    /// Slot state (EMPTY, ACTIVE, INACTIVE)
    state: AtomicU8,
    /// Timestamp when opportunity started
    active_since_ns: AtomicU64,
    /// Timestamp of last observation
    last_seen_ns: AtomicU64,
    /// Maximum profit observed (f64 bits)
    max_profit_bits: AtomicU64,
    /// Last profit observed (f64 bits)
    last_profit_bits: AtomicU64,
    /// Padding
    _pad: [u8; 7],
}

impl Default for OpportunitySlot {
    fn default() -> Self {
        Self {
            signature_id: AtomicU64::new(0),
            state: AtomicU8::new(SLOT_EMPTY),
            active_since_ns: AtomicU64::new(0),
            last_seen_ns: AtomicU64::new(0),
            max_profit_bits: AtomicU64::new(0),
            last_profit_bits: AtomicU64::new(0),
            _pad: [0; 7],
        }
    }
}

impl OpportunitySlot {
    /// Get the signature ID.
    #[inline(always)]
    pub fn signature_id(&self) -> u64 {
        self.signature_id.load(Ordering::Acquire)
    }

    /// Check if the slot is active.
    #[inline(always)]
    pub fn is_active(&self) -> bool {
        self.state.load(Ordering::Acquire) == SLOT_ACTIVE
    }

    /// Get the start timestamp.
    #[inline(always)]
    pub fn active_since_ns(&self) -> u64 {
        self.active_since_ns.load(Ordering::Acquire)
    }

    /// Get the last seen timestamp.
    #[inline(always)]
    pub fn last_seen_ns(&self) -> u64 {
        self.last_seen_ns.load(Ordering::Acquire)
    }

    /// Get the maximum profit.
    #[inline(always)]
    pub fn max_profit(&self) -> f64 {
        f64::from_bits(self.max_profit_bits.load(Ordering::Acquire))
    }

    /// Get the last profit.
    #[inline(always)]
    pub fn last_profit(&self) -> f64 {
        f64::from_bits(self.last_profit_bits.load(Ordering::Acquire))
    }
}

/// Result of updating an opportunity.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum UpdateResult {
    /// New opportunity started
    Started,
    /// Existing opportunity updated
    Updated,
    /// No change (slot full or signature mismatch)
    NoChange,
}

/// Result of expiring opportunities.
#[derive(Debug, Clone, Copy)]
pub struct ExpiredOpportunity {
    pub signature_id: u64,
    pub duration_ns: u64,
    pub max_profit: f64,
}

/// Lock-free opportunity store using open-addressed hash table.
pub struct OpportunityStore {
    /// Slots (fixed size, preallocated)
    slots: Box<[OpportunitySlot]>,
    /// Number of slots (power of 2)
    num_slots: usize,
    /// Mask for fast modulo
    mask: usize,
}

impl OpportunityStore {
    /// Create a new opportunity store with the given capacity.
    ///
    /// # Panics
    /// Panics if capacity is not a power of 2.
    pub fn new(capacity: usize) -> Self {
        assert!(capacity.is_power_of_two(), "capacity must be power of 2");

        let mut slots = Vec::with_capacity(capacity);
        for _ in 0..capacity {
            slots.push(OpportunitySlot::default());
        }

        Self {
            slots: slots.into_boxed_slice(),
            num_slots: capacity,
            mask: capacity - 1,
        }
    }

    /// Hash a signature ID to a slot index.
    #[inline(always)]
    fn hash(&self, signature_id: u64) -> usize {
        // FNV-1a inspired mixing
        let mut h = signature_id;
        h ^= h >> 33;
        h = h.wrapping_mul(0xff51afd7ed558ccd);
        h ^= h >> 33;
        (h as usize) & self.mask
    }

    /// Find or create a slot for the given signature.
    /// Returns (slot_index, is_new).
    fn find_slot(&self, signature_id: u64) -> Option<(usize, bool)> {
        let start = self.hash(signature_id);

        // Linear probing with limited search
        for i in 0..self.num_slots.min(16) {
            let idx = (start + i) & self.mask;
            let slot = &self.slots[idx];
            let slot_state = slot.state.load(Ordering::Acquire);
            let slot_sig = slot.signature_id.load(Ordering::Acquire);

            if slot_state == SLOT_EMPTY {
                // Empty slot - can use it
                return Some((idx, true));
            }

            if slot_sig == signature_id {
                // Found existing slot
                return Some((idx, false));
            }
        }

        // Table too full in this region
        None
    }

    /// Update or create an opportunity.
    #[inline]
    pub fn update(&self, signature_id: u64, profit: f64, ts_ns: u64) -> UpdateResult {
        let Some((idx, is_new)) = self.find_slot(signature_id) else {
            return UpdateResult::NoChange;
        };

        let slot = &self.slots[idx];
        let profit_bits = profit.to_bits();

        if is_new {
            // Initialize new slot
            slot.signature_id.store(signature_id, Ordering::Release);
            slot.active_since_ns.store(ts_ns, Ordering::Release);
            slot.last_seen_ns.store(ts_ns, Ordering::Release);
            slot.max_profit_bits.store(profit_bits, Ordering::Release);
            slot.last_profit_bits.store(profit_bits, Ordering::Release);
            slot.state.store(SLOT_ACTIVE, Ordering::Release);
            UpdateResult::Started
        } else {
            // Update existing slot
            slot.last_seen_ns.store(ts_ns, Ordering::Release);
            slot.last_profit_bits.store(profit_bits, Ordering::Release);

            // Update max if higher
            let current_max = slot.max_profit_bits.load(Ordering::Acquire);
            if profit_bits > current_max {
                slot.max_profit_bits.store(profit_bits, Ordering::Release);
            }

            // Reactivate if was inactive
            let prev_state = slot.state.load(Ordering::Acquire);
            if prev_state == SLOT_INACTIVE {
                slot.active_since_ns.store(ts_ns, Ordering::Release);
                slot.state.store(SLOT_ACTIVE, Ordering::Release);
                UpdateResult::Started
            } else {
                UpdateResult::Updated
            }
        }
    }

    /// Check for expired opportunities and return them.
    /// Callback is invoked for each expired opportunity.
    pub fn expire_stale<F>(&self, now_ns: u64, grace_ns: u64, mut callback: F)
    where
        F: FnMut(ExpiredOpportunity),
    {
        for slot in self.slots.iter() {
            let state = slot.state.load(Ordering::Acquire);
            if state != SLOT_ACTIVE {
                continue;
            }

            let last_seen = slot.last_seen_ns.load(Ordering::Acquire);
            if now_ns.saturating_sub(last_seen) > grace_ns {
                // Opportunity expired
                let sig = slot.signature_id.load(Ordering::Acquire);
                let start = slot.active_since_ns.load(Ordering::Acquire);
                let max_profit = slot.max_profit();

                // Mark as inactive
                slot.state.store(SLOT_INACTIVE, Ordering::Release);

                callback(ExpiredOpportunity {
                    signature_id: sig,
                    duration_ns: now_ns.saturating_sub(start),
                    max_profit,
                });
            }
        }
    }

    /// Get a slot by index (for iteration/debugging).
    #[inline]
    pub fn get_slot(&self, idx: usize) -> Option<&OpportunitySlot> {
        self.slots.get(idx)
    }

    /// Get the number of slots.
    #[inline]
    pub fn num_slots(&self) -> usize {
        self.num_slots
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_new_opportunity() {
        let store = OpportunityStore::new(16);

        let result = store.update(12345, 1.005, 1000);
        assert_eq!(result, UpdateResult::Started);

        let result = store.update(12345, 1.006, 2000);
        assert_eq!(result, UpdateResult::Updated);
    }

    #[test]
    fn test_expiration() {
        let store = OpportunityStore::new(16);

        store.update(12345, 1.005, 1000);

        let mut expired = Vec::new();
        store.expire_stale(5000, 1000, |e| expired.push(e));

        assert_eq!(expired.len(), 1);
        assert_eq!(expired[0].signature_id, 12345);
        assert_eq!(expired[0].duration_ns, 4000);
    }

    #[test]
    fn test_reactivation() {
        let store = OpportunityStore::new(16);

        store.update(12345, 1.005, 1000);
        store.expire_stale(5000, 1000, |_| {});

        // Reactivate
        let result = store.update(12345, 1.007, 6000);
        assert_eq!(result, UpdateResult::Started);
    }
}
