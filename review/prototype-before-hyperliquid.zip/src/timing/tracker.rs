//! Opportunity timing and lifecycle tracking.
//!
//! Wraps the opportunity store with event emission for the logging thread.

use crate::ring_buffer::SpscRingBuffer;
use crate::state::{ExpiredOpportunity, OpportunityStore, UpdateResult};
use crate::types::ArbitrageEvent;

/// Opportunity tracker that emits events to the logging thread.
pub struct OpportunityTracker {
    /// Underlying store
    store: OpportunityStore,
    /// Minimum profit threshold (basis points)
    min_profit_bps: u32,
}

impl OpportunityTracker {
    /// Create a new opportunity tracker.
    pub fn new(capacity: usize, min_profit_bps: u32) -> Self {
        Self {
            store: OpportunityStore::new(capacity),
            min_profit_bps,
        }
    }

    /// Update or create an opportunity, emitting events as needed.
    ///
    /// # Arguments
    /// * `signature_id` - Canonical cycle signature
    /// * `profit_bps` - Current profit in basis points
    /// * `ts_ns` - Current timestamp
    /// * `event_buffer` - Ring buffer for event emission (optional)
    ///
    /// # Returns
    /// The update result
    #[inline]
    pub fn update(
        &self,
        signature_id: u64,
        profit_bps: u32,
        ts_ns: u64,
        event_buffer: Option<&SpscRingBuffer<ArbitrageEvent>>,
    ) -> UpdateResult {
        // Check minimum profit threshold
        if profit_bps < self.min_profit_bps {
            return UpdateResult::NoChange;
        }

        let result = self.store.update(signature_id, profit_bps as f64 / 10000.0, ts_ns);

        // Emit event if buffer provided
        if let Some(buffer) = event_buffer {
            let event = match result {
                UpdateResult::Started => ArbitrageEvent::started(signature_id, profit_bps, ts_ns),
                UpdateResult::Updated => ArbitrageEvent::updated(signature_id, profit_bps, ts_ns),
                UpdateResult::NoChange => return result,
            };
            let _ = buffer.try_push(event); // Drop if full
        }

        result
    }

    /// Check for expired opportunities and emit end events.
    #[inline]
    pub fn expire_stale(
        &self,
        now_ns: u64,
        grace_ns: u64,
        event_buffer: Option<&SpscRingBuffer<ArbitrageEvent>>,
    ) {
        self.store.expire_stale(now_ns, grace_ns, |expired: ExpiredOpportunity| {
            if let Some(buffer) = event_buffer {
                let event = ArbitrageEvent::ended(expired.signature_id, expired.duration_ns, now_ns);
                let _ = buffer.try_push(event);
            }
        });
    }

    /// Get the underlying store for direct access.
    pub fn store(&self) -> &OpportunityStore {
        &self.store
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::ring_buffer::OverflowPolicy;

    #[test]
    fn test_tracker_with_events() {
        let tracker = OpportunityTracker::new(16, 5);
        let event_buffer: SpscRingBuffer<ArbitrageEvent> =
            SpscRingBuffer::new(16, OverflowPolicy::DropNewest);

        // First update should emit Started
        let result = tracker.update(12345, 10, 1000, Some(&event_buffer));
        assert_eq!(result, UpdateResult::Started);

        let event = event_buffer.try_pop().unwrap();
        assert_eq!(event.signature_id, 12345);
        assert_eq!(event.profit_bps, 10);

        // Second update should emit Updated
        let result = tracker.update(12345, 15, 2000, Some(&event_buffer));
        assert_eq!(result, UpdateResult::Updated);

        let event = event_buffer.try_pop().unwrap();
        assert_eq!(event.profit_bps, 15);
    }

    #[test]
    fn test_below_threshold() {
        let tracker = OpportunityTracker::new(16, 10);
        let event_buffer: SpscRingBuffer<ArbitrageEvent> =
            SpscRingBuffer::new(16, OverflowPolicy::DropNewest);

        // Below threshold, should not emit
        let result = tracker.update(12345, 5, 1000, Some(&event_buffer));
        assert_eq!(result, UpdateResult::NoChange);
        assert!(event_buffer.try_pop().is_none());
    }
}
