//! Opportunity timing and lifecycle tracking.

mod tracker;

pub use tracker::OpportunityTracker;
