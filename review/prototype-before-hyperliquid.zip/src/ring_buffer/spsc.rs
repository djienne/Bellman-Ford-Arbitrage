//! Lock-free Single-Producer Single-Consumer ring buffer.
//!
//! Designed for hot-path usage with zero allocations after initialization.

use crossbeam_utils::CachePadded;
use std::cell::UnsafeCell;
use std::sync::atomic::{AtomicUsize, Ordering};

/// Overflow policy when the buffer is full.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum OverflowPolicy {
    /// Drop the newest item (preserve sequencing)
    DropNewest,
    /// Overwrite the oldest item (always have fresh data)
    OverwriteOldest,
}

/// Lock-free SPSC ring buffer.
///
/// # Safety
/// - Only one thread may call `try_push` (producer)
/// - Only one thread may call `try_pop` (consumer)
/// - The buffer is safe to share between threads via Arc
pub struct SpscRingBuffer<T> {
    /// Buffer storage (power of 2 capacity)
    buffer: Box<[UnsafeCell<T>]>,
    /// Capacity mask for fast modulo (capacity - 1)
    mask: usize,
    /// Producer write position (cache-line padded)
    head: CachePadded<AtomicUsize>,
    /// Consumer read position (cache-line padded)
    tail: CachePadded<AtomicUsize>,
    /// Overflow policy
    policy: OverflowPolicy,
}

// Safety: The buffer is designed for single-producer single-consumer use.
// The atomic head/tail provide synchronization between threads.
unsafe impl<T: Send> Send for SpscRingBuffer<T> {}
unsafe impl<T: Send> Sync for SpscRingBuffer<T> {}

impl<T: Copy + Default> SpscRingBuffer<T> {
    /// Create a new ring buffer with the given capacity.
    ///
    /// # Panics
    /// Panics if capacity is not a power of 2.
    pub fn new(capacity: usize, policy: OverflowPolicy) -> Self {
        assert!(capacity.is_power_of_two(), "capacity must be power of 2");
        assert!(capacity > 0, "capacity must be > 0");

        // Allocate and initialize buffer
        let mut buffer = Vec::with_capacity(capacity);
        for _ in 0..capacity {
            buffer.push(UnsafeCell::new(T::default()));
        }

        Self {
            buffer: buffer.into_boxed_slice(),
            mask: capacity - 1,
            head: CachePadded::new(AtomicUsize::new(0)),
            tail: CachePadded::new(AtomicUsize::new(0)),
            policy,
        }
    }

    /// Get the capacity of the buffer.
    #[inline]
    pub fn capacity(&self) -> usize {
        self.mask + 1
    }

    /// Try to push an item. Returns true if successful.
    ///
    /// # Safety
    /// Must only be called from a single producer thread.
    #[inline]
    pub fn try_push(&self, item: T) -> bool {
        let head = self.head.load(Ordering::Relaxed);
        let tail = self.tail.load(Ordering::Acquire);

        let next_head = head.wrapping_add(1);

        // Check if full
        if (next_head & self.mask) == (tail & self.mask) && next_head != tail {
            // Buffer is full
            match self.policy {
                OverflowPolicy::DropNewest => return false,
                OverflowPolicy::OverwriteOldest => {
                    // Advance tail to make room (drops oldest)
                    self.tail.store(tail.wrapping_add(1), Ordering::Release);
                }
            }
        }

        // Write item
        unsafe {
            *self.buffer[head & self.mask].get() = item;
        }

        // Publish
        self.head.store(next_head, Ordering::Release);
        true
    }

    /// Try to pop an item. Returns None if empty.
    ///
    /// # Safety
    /// Must only be called from a single consumer thread.
    #[inline]
    pub fn try_pop(&self) -> Option<T> {
        let tail = self.tail.load(Ordering::Relaxed);
        let head = self.head.load(Ordering::Acquire);

        // Check if empty
        if tail == head {
            return None;
        }

        // Read item
        let item = unsafe { *self.buffer[tail & self.mask].get() };

        // Advance tail
        self.tail.store(tail.wrapping_add(1), Ordering::Release);

        Some(item)
    }

    /// Check if the buffer is empty.
    #[inline]
    pub fn is_empty(&self) -> bool {
        let tail = self.tail.load(Ordering::Relaxed);
        let head = self.head.load(Ordering::Acquire);
        tail == head
    }

    /// Get the current number of items in the buffer (approximate).
    #[inline]
    pub fn len(&self) -> usize {
        let head = self.head.load(Ordering::Relaxed);
        let tail = self.tail.load(Ordering::Relaxed);
        head.wrapping_sub(tail)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_basic_push_pop() {
        let buffer: SpscRingBuffer<u32> = SpscRingBuffer::new(4, OverflowPolicy::DropNewest);

        assert!(buffer.is_empty());
        assert!(buffer.try_push(1));
        assert!(buffer.try_push(2));
        assert!(!buffer.is_empty());

        assert_eq!(buffer.try_pop(), Some(1));
        assert_eq!(buffer.try_pop(), Some(2));
        assert_eq!(buffer.try_pop(), None);
        assert!(buffer.is_empty());
    }

    #[test]
    fn test_overflow_drop_newest() {
        let buffer: SpscRingBuffer<u32> = SpscRingBuffer::new(2, OverflowPolicy::DropNewest);

        assert!(buffer.try_push(1));
        // Buffer has 1 slot used, 1 free. But we use wrapping semantics
        // so we can fill to capacity - 1 effectively.
        // With capacity 2, we can hold 1 item before "full" check triggers

        // Let's test with larger buffer
        let buffer: SpscRingBuffer<u32> = SpscRingBuffer::new(4, OverflowPolicy::DropNewest);
        assert!(buffer.try_push(1));
        assert!(buffer.try_push(2));
        assert!(buffer.try_push(3));
        // 4th push should fail (buffer full at capacity-1)
        assert!(!buffer.try_push(4));

        assert_eq!(buffer.try_pop(), Some(1));
        assert_eq!(buffer.try_pop(), Some(2));
        assert_eq!(buffer.try_pop(), Some(3));
    }

    #[test]
    fn test_overflow_overwrite_oldest() {
        let buffer: SpscRingBuffer<u32> = SpscRingBuffer::new(4, OverflowPolicy::OverwriteOldest);

        assert!(buffer.try_push(1));
        assert!(buffer.try_push(2));
        assert!(buffer.try_push(3));
        // This should overwrite oldest (1)
        assert!(buffer.try_push(4));

        assert_eq!(buffer.try_pop(), Some(2));
        assert_eq!(buffer.try_pop(), Some(3));
        assert_eq!(buffer.try_pop(), Some(4));
        assert_eq!(buffer.try_pop(), None);
    }

    #[test]
    fn test_wrap_around() {
        let buffer: SpscRingBuffer<u32> = SpscRingBuffer::new(4, OverflowPolicy::DropNewest);

        for i in 0..10 {
            assert!(buffer.try_push(i));
            assert_eq!(buffer.try_pop(), Some(i));
        }
    }
}
