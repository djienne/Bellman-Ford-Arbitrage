//! Lock-free ring buffers for inter-thread communication.

mod spsc;

pub use spsc::{OverflowPolicy, SpscRingBuffer};
