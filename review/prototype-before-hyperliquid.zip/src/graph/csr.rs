//! Compressed Sparse Row (CSR) graph representation.
//!
//! Optimized for cache-friendly traversal in Bellman-Ford.

use crate::types::EDGE_SELL_BID;

/// Graph in CSR format with Structure-of-Arrays edge data.
///
/// For each trading pair, two directed edges are created:
/// - SELL: BASE -> QUOTE (uses bid price)
/// - BUY: QUOTE -> BASE (uses ask price)
#[derive(Debug)]
pub struct Graph {
    /// Number of nodes (currencies)
    pub num_nodes: u32,
    /// Number of edges (2 * num_symbols)
    pub num_edges: u32,

    // Edge data (SoA layout for cache efficiency)
    /// Source node for each edge
    pub edge_from: Vec<u32>,
    /// Destination node for each edge
    pub edge_to: Vec<u32>,
    /// Edge type: EDGE_SELL_BID or EDGE_BUY_ASK
    pub edge_kind: Vec<u8>,
    /// Symbol index for price lookup
    pub edge_symbol: Vec<u32>,

    // CSR adjacency structure
    /// Start index of outgoing edges for each node [num_nodes + 1]
    pub out_start: Vec<u32>,
    /// Edge indices sorted by source node [num_edges]
    pub out_edges: Vec<u32>,
}

impl Graph {
    /// Create an empty graph.
    pub fn new() -> Self {
        Self {
            num_nodes: 0,
            num_edges: 0,
            edge_from: Vec::new(),
            edge_to: Vec::new(),
            edge_kind: Vec::new(),
            edge_symbol: Vec::new(),
            out_start: Vec::new(),
            out_edges: Vec::new(),
        }
    }

    /// Get the outgoing edges for a node.
    #[inline(always)]
    pub fn outgoing_edges(&self, node: u32) -> &[u32] {
        let start = self.out_start[node as usize] as usize;
        let end = self.out_start[node as usize + 1] as usize;
        &self.out_edges[start..end]
    }

    /// Get edge info by index.
    #[inline(always)]
    pub fn edge(&self, edge_idx: u32) -> (u32, u32, u8, u32) {
        let idx = edge_idx as usize;
        (
            self.edge_from[idx],
            self.edge_to[idx],
            self.edge_kind[idx],
            self.edge_symbol[idx],
        )
    }

    /// Get the source node of an edge.
    #[inline(always)]
    pub fn edge_from(&self, edge_idx: u32) -> u32 {
        self.edge_from[edge_idx as usize]
    }

    /// Get the destination node of an edge.
    #[inline(always)]
    pub fn edge_to(&self, edge_idx: u32) -> u32 {
        self.edge_to[edge_idx as usize]
    }

    /// Get the edge type.
    #[inline(always)]
    pub fn edge_kind(&self, edge_idx: u32) -> u8 {
        self.edge_kind[edge_idx as usize]
    }

    /// Get the symbol index for an edge.
    #[inline(always)]
    pub fn edge_symbol(&self, edge_idx: u32) -> u32 {
        self.edge_symbol[edge_idx as usize]
    }

    /// Check if the edge uses bid price (SELL direction).
    #[inline(always)]
    pub fn is_sell_edge(&self, edge_idx: u32) -> bool {
        self.edge_kind[edge_idx as usize] == EDGE_SELL_BID
    }

    /// Get the edges associated with a symbol (SELL and BUY).
    #[inline]
    pub fn symbol_edges(&self, symbol_index: u32) -> (u32, u32) {
        // By construction, edge 2*i is SELL, 2*i+1 is BUY
        (symbol_index * 2, symbol_index * 2 + 1)
    }
}

impl Default for Graph {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_empty_graph() {
        let graph = Graph::new();
        assert_eq!(graph.num_nodes, 0);
        assert_eq!(graph.num_edges, 0);
    }
}
