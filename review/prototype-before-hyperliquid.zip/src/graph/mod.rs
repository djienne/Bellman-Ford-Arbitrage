//! Graph representation for Bellman-Ford algorithm.

mod builder;
mod csr;

pub use builder::GraphBuilder;
pub use csr::Graph;
