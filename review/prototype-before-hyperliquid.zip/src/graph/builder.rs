//! Graph builder - constructs CSR graph from symbol metadata.

use super::csr::Graph;
use crate::types::{SymbolMeta, EDGE_BUY_ASK, EDGE_SELL_BID};
use std::collections::HashMap;

/// Metadata about the graph construction.
#[derive(Debug)]
pub struct GraphMeta {
    /// Currency name to ID mapping (cold path only)
    pub currency_to_id: HashMap<String, u32>,
    /// ID to currency name mapping (cold path only)
    pub id_to_currency: Vec<String>,
    /// Symbol name to index mapping (cold path only)
    pub symbol_to_index: HashMap<String, u32>,
    /// Symbol index to name mapping (cold path only)
    pub index_to_symbol: Vec<String>,
    /// Base currency ID for each symbol
    pub symbol_base: Vec<u32>,
    /// Quote currency ID for each symbol
    pub symbol_quote: Vec<u32>,
}

impl GraphMeta {
    /// Get the currency ID, or None if not found.
    pub fn currency_id(&self, currency: &str) -> Option<u32> {
        self.currency_to_id.get(currency).copied()
    }

    /// Get the currency name by ID.
    pub fn currency_name(&self, id: u32) -> Option<&str> {
        self.id_to_currency.get(id as usize).map(|s| s.as_str())
    }

    /// Get the symbol index, or None if not found.
    pub fn symbol_index(&self, symbol: &str) -> Option<u32> {
        self.symbol_to_index.get(symbol).copied()
    }

    /// Get the symbol name by index.
    pub fn symbol_name(&self, index: u32) -> Option<&str> {
        self.index_to_symbol.get(index as usize).map(|s| s.as_str())
    }
}

/// Builder for constructing graphs from symbol metadata.
pub struct GraphBuilder {
    currency_to_id: HashMap<String, u32>,
    id_to_currency: Vec<String>,
    next_currency_id: u32,
}

impl GraphBuilder {
    pub fn new() -> Self {
        Self {
            currency_to_id: HashMap::new(),
            id_to_currency: Vec::new(),
            next_currency_id: 0,
        }
    }

    /// Get or create a currency ID.
    fn get_or_create_currency(&mut self, currency: &str) -> u32 {
        if let Some(&id) = self.currency_to_id.get(currency) {
            return id;
        }
        let id = self.next_currency_id;
        self.currency_to_id.insert(currency.to_string(), id);
        self.id_to_currency.push(currency.to_string());
        self.next_currency_id += 1;
        id
    }

    /// Build a graph from symbol metadata.
    pub fn build(mut self, symbols: &[SymbolMeta]) -> (Graph, GraphMeta) {
        let num_symbols = symbols.len();

        // First pass: assign currency IDs and symbol indices
        let mut symbol_to_index = HashMap::new();
        let mut index_to_symbol = Vec::with_capacity(num_symbols);
        let mut symbol_base = Vec::with_capacity(num_symbols);
        let mut symbol_quote = Vec::with_capacity(num_symbols);

        for (idx, meta) in symbols.iter().enumerate() {
            let base_id = self.get_or_create_currency(&meta.base_asset);
            let quote_id = self.get_or_create_currency(&meta.quote_asset);

            symbol_to_index.insert(meta.symbol.clone(), idx as u32);
            index_to_symbol.push(meta.symbol.clone());
            symbol_base.push(base_id);
            symbol_quote.push(quote_id);
        }

        let num_nodes = self.next_currency_id;
        let num_edges = (num_symbols * 2) as u32;

        // Build edge arrays
        // For each symbol, create two edges:
        // - SELL: BASE -> QUOTE (index 2*i)
        // - BUY: QUOTE -> BASE (index 2*i + 1)
        let mut edge_from = Vec::with_capacity(num_edges as usize);
        let mut edge_to = Vec::with_capacity(num_edges as usize);
        let mut edge_kind = Vec::with_capacity(num_edges as usize);
        let mut edge_symbol = Vec::with_capacity(num_edges as usize);

        for (symbol_idx, _meta) in symbols.iter().enumerate() {
            let base_id = symbol_base[symbol_idx];
            let quote_id = symbol_quote[symbol_idx];

            // SELL edge: BASE -> QUOTE
            edge_from.push(base_id);
            edge_to.push(quote_id);
            edge_kind.push(EDGE_SELL_BID);
            edge_symbol.push(symbol_idx as u32);

            // BUY edge: QUOTE -> BASE
            edge_from.push(quote_id);
            edge_to.push(base_id);
            edge_kind.push(EDGE_BUY_ASK);
            edge_symbol.push(symbol_idx as u32);
        }

        // Build CSR adjacency list
        // Count outgoing edges per node
        let mut out_degree = vec![0u32; num_nodes as usize];
        for &from in &edge_from {
            out_degree[from as usize] += 1;
        }

        // Compute prefix sums for out_start
        let mut out_start = Vec::with_capacity(num_nodes as usize + 1);
        out_start.push(0);
        let mut sum = 0u32;
        for &deg in &out_degree {
            sum += deg;
            out_start.push(sum);
        }

        // Place edges into out_edges
        let mut out_edges = vec![0u32; num_edges as usize];
        let mut current_pos = out_start.clone();
        current_pos.pop(); // Remove last element

        for edge_idx in 0..num_edges {
            let from = edge_from[edge_idx as usize] as usize;
            let pos = current_pos[from] as usize;
            out_edges[pos] = edge_idx;
            current_pos[from] += 1;
        }

        let graph = Graph {
            num_nodes,
            num_edges,
            edge_from,
            edge_to,
            edge_kind,
            edge_symbol,
            out_start,
            out_edges,
        };

        let meta = GraphMeta {
            currency_to_id: self.currency_to_id,
            id_to_currency: self.id_to_currency,
            symbol_to_index,
            index_to_symbol,
            symbol_base,
            symbol_quote,
        };

        (graph, meta)
    }
}

impl Default for GraphBuilder {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn make_symbol(symbol: &str, base: &str, quote: &str) -> SymbolMeta {
        SymbolMeta {
            symbol: symbol.to_string(),
            base_asset: base.to_string(),
            quote_asset: quote.to_string(),
            quote_volume_24h: 1000.0,
        }
    }

    #[test]
    fn test_simple_triangle() {
        let symbols = vec![
            make_symbol("BTCUSDT", "BTC", "USDT"),
            make_symbol("ETHUSDT", "ETH", "USDT"),
            make_symbol("ETHBTC", "ETH", "BTC"),
        ];

        let builder = GraphBuilder::new();
        let (graph, meta) = builder.build(&symbols);

        // 3 currencies: BTC, USDT, ETH
        assert_eq!(graph.num_nodes, 3);
        // 3 symbols * 2 edges each = 6 edges
        assert_eq!(graph.num_edges, 6);

        // Verify currency mappings
        assert!(meta.currency_to_id.contains_key("BTC"));
        assert!(meta.currency_to_id.contains_key("USDT"));
        assert!(meta.currency_to_id.contains_key("ETH"));

        // Verify symbol mappings
        assert_eq!(meta.symbol_index("BTCUSDT"), Some(0));
        assert_eq!(meta.symbol_index("ETHUSDT"), Some(1));
        assert_eq!(meta.symbol_index("ETHBTC"), Some(2));
    }

    #[test]
    fn test_csr_structure() {
        let symbols = vec![
            make_symbol("BTCUSDT", "BTC", "USDT"),
            make_symbol("ETHBTC", "ETH", "BTC"),
        ];

        let builder = GraphBuilder::new();
        let (graph, meta) = builder.build(&symbols);

        let btc_id = meta.currency_id("BTC").unwrap();
        let usdt_id = meta.currency_id("USDT").unwrap();
        let eth_id = meta.currency_id("ETH").unwrap();

        // Check outgoing edges from BTC
        let btc_out = graph.outgoing_edges(btc_id);
        // BTC should have: SELL to USDT, BUY from ETH
        assert!(!btc_out.is_empty());

        // Verify edge destinations
        for &edge_idx in btc_out {
            let to = graph.edge_to(edge_idx);
            // Edges from BTC go to either USDT or ETH
            assert!(to == usdt_id || to == eth_id);
        }
    }
}
