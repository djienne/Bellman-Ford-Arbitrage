//! Core types for the arbitrage detector.
//!
//! All types here are designed for zero-allocation hot path usage.

/// Edge direction constants
pub const EDGE_SELL_BID: u8 = 0; // BASE -> QUOTE, uses bid price
pub const EDGE_BUY_ASK: u8 = 1; // QUOTE -> BASE, uses ask price

/// Best bid/ask update from exchange.
/// This is the normalized format pushed into the ingestion ring buffer.
/// ln(bid) and ln(ask) are pre-computed in the collector thread to avoid
/// calling ln() in the hot path.
#[repr(C)]
#[derive(Clone, Copy, Debug, Default)]
pub struct BestBidAskUpdate {
    /// Index into the symbol table (0-based)
    pub symbol_index: u32,
    /// Best bid price as f64 bits (use f64::from_bits to convert)
    pub bid_bits: u64,
    /// Best ask price as f64 bits
    pub ask_bits: u64,
    /// ln(bid) precomputed as f64 bits
    pub ln_bid_bits: u64,
    /// ln(ask) precomputed as f64 bits
    pub ln_ask_bits: u64,
    /// Timestamp in nanoseconds (from exchange or receive time)
    pub ts_ns: u64,
}

impl BestBidAskUpdate {
    /// Create a new update with pre-computed ln values.
    /// The ln() calls happen here in the collector thread, not the hot path.
    #[inline(always)]
    pub fn new(symbol_index: u32, bid: f64, ask: f64, ts_ns: u64) -> Self {
        let ln_bid = if bid > 0.0 { bid.ln() } else { f64::NEG_INFINITY };
        let ln_ask = if ask > 0.0 { ask.ln() } else { f64::INFINITY };
        Self {
            symbol_index,
            bid_bits: bid.to_bits(),
            ask_bits: ask.to_bits(),
            ln_bid_bits: ln_bid.to_bits(),
            ln_ask_bits: ln_ask.to_bits(),
            ts_ns,
        }
    }

    #[inline(always)]
    pub fn bid(&self) -> f64 {
        f64::from_bits(self.bid_bits)
    }

    #[inline(always)]
    pub fn ask(&self) -> f64 {
        f64::from_bits(self.ask_bits)
    }

    #[inline(always)]
    pub fn ln_bid(&self) -> f64 {
        f64::from_bits(self.ln_bid_bits)
    }

    #[inline(always)]
    pub fn ln_ask(&self) -> f64 {
        f64::from_bits(self.ln_ask_bits)
    }
}

/// Arbitrage event types
#[repr(u8)]
#[derive(Clone, Copy, Debug, PartialEq, Eq, Default)]
pub enum ArbitrageEventKind {
    #[default]
    Started = 0,
    Updated = 1,
    Ended = 2,
}

/// Compact arbitrage event for hot path -> cold path logging.
#[repr(C)]
#[derive(Clone, Copy, Debug, Default)]
pub struct ArbitrageEvent {
    /// Event type
    pub kind: ArbitrageEventKind,
    /// Canonical cycle signature
    pub signature_id: u64,
    /// Profit in basis points (e.g., 15 = 0.15%)
    pub profit_bps: u32,
    /// Duration in nanoseconds (only for Ended events)
    pub duration_ns: u64,
    /// Event timestamp in nanoseconds
    pub ts_ns: u64,
}

impl ArbitrageEvent {
    #[inline(always)]
    pub fn started(signature_id: u64, profit_bps: u32, ts_ns: u64) -> Self {
        Self {
            kind: ArbitrageEventKind::Started,
            signature_id,
            profit_bps,
            duration_ns: 0,
            ts_ns,
        }
    }

    #[inline(always)]
    pub fn updated(signature_id: u64, profit_bps: u32, ts_ns: u64) -> Self {
        Self {
            kind: ArbitrageEventKind::Updated,
            signature_id,
            profit_bps,
            duration_ns: 0,
            ts_ns,
        }
    }

    #[inline(always)]
    pub fn ended(signature_id: u64, duration_ns: u64, ts_ns: u64) -> Self {
        Self {
            kind: ArbitrageEventKind::Ended,
            signature_id,
            profit_bps: 0,
            duration_ns,
            ts_ns,
        }
    }
}

/// Symbol metadata from exchange discovery.
/// Used during initialization, not on hot path.
#[derive(Clone, Debug)]
pub struct SymbolMeta {
    pub symbol: String,
    pub base_asset: String,
    pub quote_asset: String,
    pub quote_volume_24h: f64,
}
