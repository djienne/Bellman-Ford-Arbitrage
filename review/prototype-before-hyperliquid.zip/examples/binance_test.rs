//! Integration test for Binance API connectivity.
//!
//! Tests:
//! 1. REST API - Symbol discovery (triangular arbitrage mode)
//! 2. Verify triangular arbitrage paths exist
//! 3. WebSocket - Single symbol streaming
//! 4. WebSocket - Multiple symbols streaming
//!
//! Run with: cargo run --example binance_test

use anyhow::{Context, Result};
use bellman_arb::collectors::{BinanceCollector, ExchangeCollector};
use bellman_arb::ring_buffer::{OverflowPolicy, SpscRingBuffer};
use bellman_arb::types::BestBidAskUpdate;
use bellman_arb::Config;
use std::collections::{HashMap, HashSet};
use std::sync::Arc;
use std::time::Duration;
use tracing_subscriber::EnvFilter;

#[tokio::main]
async fn main() -> Result<()> {
    // Initialize logging
    tracing_subscriber::fmt()
        .with_env_filter(
            EnvFilter::from_default_env()
                .add_directive("bellman_arb=debug".parse()?)
                .add_directive("binance_test=info".parse()?),
        )
        .init();

    println!("\n========================================");
    println!("  Binance API Integration Test");
    println!("========================================\n");

    // Test 1: REST API - Symbol Discovery (Triangular Mode)
    let symbols = test_triangular_discovery().await?;

    // Test 2: Verify triangular paths exist
    test_triangular_paths(&symbols)?;

    // Test 3: WebSocket - Single Symbol
    test_websocket_single_symbol().await?;

    // Test 4: WebSocket - Multiple Symbols (from triangular set)
    test_websocket_multiple_symbols(&symbols).await?;

    println!("\n========================================");
    println!("  All tests passed!");
    println!("========================================\n");

    Ok(())
}

/// Test 1: REST API triangular arbitrage symbol discovery
async fn test_triangular_discovery() -> Result<Vec<bellman_arb::types::SymbolMeta>> {
    println!("----------------------------------------");
    println!("TEST 1: REST API - Triangular Arbitrage Discovery");
    println!("----------------------------------------");

    let collector = BinanceCollector::new();
    let config = Config {
        top_pairs: 10, // Top 10 base assets
        hub_assets: vec![
            "USDT".to_string(),
            "BTC".to_string(),
            "ETH".to_string(),
        ],
        quote_filter: None, // Use triangular mode
        ..Config::default()
    };

    println!("Discovering pairs for triangular arbitrage...");
    println!("  Hub assets: {:?}", config.hub_assets);
    println!("  Top base assets: {}", config.top_pairs);

    let symbols = collector
        .discover_pairs(&config)
        .await
        .context("Failed to discover pairs")?;

    println!("\nDiscovered {} pairs:", symbols.len());

    // Group by quote asset for display
    let mut by_quote: HashMap<&str, Vec<&str>> = HashMap::new();
    for sym in &symbols {
        by_quote
            .entry(&sym.quote_asset)
            .or_default()
            .push(&sym.symbol);
    }

    for (quote, pairs) in by_quote.iter() {
        println!("  {} pairs ({}): {:?}", quote, pairs.len(), pairs);
    }

    assert!(!symbols.is_empty(), "Should discover pairs");
    assert!(symbols.len() > 10, "Should have more than 10 pairs for triangular arb");

    println!("\n[PASS] Triangular discovery working correctly\n");
    Ok(symbols)
}

/// Test 2: Verify triangular arbitrage paths exist
fn test_triangular_paths(symbols: &[bellman_arb::types::SymbolMeta]) -> Result<()> {
    println!("----------------------------------------");
    println!("TEST 2: Verify Triangular Arbitrage Paths");
    println!("----------------------------------------");

    // Build adjacency: currency -> set of currencies it can trade to
    let mut adjacency: HashMap<&str, HashSet<&str>> = HashMap::new();

    for sym in symbols {
        // base -> quote (selling base for quote)
        adjacency
            .entry(&sym.base_asset)
            .or_default()
            .insert(&sym.quote_asset);
        // quote -> base (buying base with quote)
        adjacency
            .entry(&sym.quote_asset)
            .or_default()
            .insert(&sym.base_asset);
    }

    println!("Currency graph nodes: {}", adjacency.len());
    for (currency, neighbors) in &adjacency {
        println!("  {} -> {:?}", currency, neighbors);
    }

    // Find all triangular paths starting and ending at USDT
    let mut triangles: Vec<(String, String, String)> = Vec::new();
    let start = "USDT";

    if let Some(first_hops) = adjacency.get(start) {
        for &hop1 in first_hops {
            if hop1 == start {
                continue;
            }
            if let Some(second_hops) = adjacency.get(hop1) {
                for &hop2 in second_hops {
                    if hop2 == start || hop2 == hop1 {
                        continue;
                    }
                    if let Some(third_hops) = adjacency.get(hop2) {
                        if third_hops.contains(start) {
                            triangles.push((
                                start.to_string(),
                                hop1.to_string(),
                                hop2.to_string(),
                            ));
                        }
                    }
                }
            }
        }
    }

    println!("\nFound {} triangular paths starting from USDT:", triangles.len());
    for (i, (a, b, c)) in triangles.iter().take(20).enumerate() {
        println!("  {}. {} -> {} -> {} -> {}", i + 1, a, b, c, a);
    }
    if triangles.len() > 20 {
        println!("  ... and {} more", triangles.len() - 20);
    }

    assert!(
        triangles.len() >= 5,
        "Should find at least 5 triangular paths, found {}",
        triangles.len()
    );

    // Verify some specific important triangles exist
    let has_btc_eth = triangles.iter().any(|(_, b, c)| {
        (b == "BTC" && c == "ETH") || (b == "ETH" && c == "BTC")
    });
    println!("\nKey triangles:");
    println!("  USDT-BTC-ETH or USDT-ETH-BTC: {}", if has_btc_eth { "YES" } else { "NO" });

    assert!(has_btc_eth, "Should have USDT-BTC-ETH triangle");

    println!("\n[PASS] Triangular paths verified\n");
    Ok(())
}

/// Test 3: WebSocket single symbol streaming
async fn test_websocket_single_symbol() -> Result<()> {
    println!("----------------------------------------");
    println!("TEST 3: WebSocket - Single Symbol (BTCUSDT)");
    println!("----------------------------------------");

    let collector = BinanceCollector::new();
    let buffer: Arc<SpscRingBuffer<BestBidAskUpdate>> =
        Arc::new(SpscRingBuffer::new(1024, OverflowPolicy::DropNewest));

    let symbols = vec!["BTCUSDT".to_string()];
    let mut symbol_indices = HashMap::new();
    symbol_indices.insert("BTCUSDT".to_string(), 0u32);

    println!("Connecting to WebSocket for BTCUSDT...");
    println!("Collecting updates for 5 seconds...\n");

    let buffer_clone = Arc::clone(&buffer);
    let handle = tokio::spawn(async move {
        collector
            .start_streaming(symbols, symbol_indices, buffer_clone)
            .await
    });

    // Collect updates for 5 seconds
    let mut update_count = 0;
    let start = std::time::Instant::now();
    let duration = Duration::from_secs(5);

    while start.elapsed() < duration {
        while let Some(update) = buffer.try_pop() {
            update_count += 1;
            if update_count <= 5 {
                println!(
                    "  Update #{}: bid={:.2}, ask={:.2}, spread={:.4}%",
                    update_count,
                    update.bid(),
                    update.ask(),
                    (update.ask() - update.bid()) / update.bid() * 100.0
                );
            } else if update_count == 6 {
                println!("  ... (more updates arriving)");
            }
        }
        tokio::time::sleep(Duration::from_millis(10)).await;
    }

    handle.abort();

    println!("\nReceived {} updates in 5 seconds", update_count);
    assert!(update_count > 0, "Should receive at least one update");

    println!("[PASS] Single symbol WebSocket working correctly\n");
    Ok(())
}

/// Test 4: WebSocket multiple symbols streaming (triangular set)
async fn test_websocket_multiple_symbols(symbols: &[bellman_arb::types::SymbolMeta]) -> Result<()> {
    println!("----------------------------------------");
    println!("TEST 4: WebSocket - Triangular Arbitrage Symbols");
    println!("----------------------------------------");

    let collector = BinanceCollector::new();
    let buffer: Arc<SpscRingBuffer<BestBidAskUpdate>> =
        Arc::new(SpscRingBuffer::new(8192, OverflowPolicy::DropNewest));

    // Use the discovered symbols (take first 20 to keep it manageable)
    let test_symbols: Vec<String> = symbols
        .iter()
        .take(20)
        .map(|s| s.symbol.clone())
        .collect();

    let mut symbol_indices = HashMap::new();
    for (i, sym) in test_symbols.iter().enumerate() {
        symbol_indices.insert(sym.clone(), i as u32);
    }

    // Reverse map for display
    let index_to_symbol: HashMap<u32, String> = symbol_indices
        .iter()
        .map(|(k, v)| (*v, k.clone()))
        .collect();

    println!("Connecting to WebSocket for {} symbols...", test_symbols.len());
    println!("Symbols: {:?}", test_symbols);
    println!("Collecting updates for 5 seconds...\n");

    let buffer_clone = Arc::clone(&buffer);
    let handle = tokio::spawn(async move {
        collector
            .start_streaming(test_symbols, symbol_indices, buffer_clone)
            .await
    });

    // Track updates per symbol
    let mut updates_per_symbol: HashMap<u32, usize> = HashMap::new();
    let mut total_updates = 0;
    let mut sample_prices: HashMap<u32, (f64, f64)> = HashMap::new();

    let start = std::time::Instant::now();
    let duration = Duration::from_secs(5);

    while start.elapsed() < duration {
        while let Some(update) = buffer.try_pop() {
            total_updates += 1;
            *updates_per_symbol.entry(update.symbol_index).or_insert(0) += 1;
            sample_prices.insert(update.symbol_index, (update.bid(), update.ask()));
        }
        tokio::time::sleep(Duration::from_millis(10)).await;
    }

    handle.abort();

    println!("Results after 5 seconds:");
    println!("  Total updates: {}", total_updates);
    println!("  Symbols with updates: {}", updates_per_symbol.len());

    println!("\n  Updates per symbol:");
    let mut sorted_updates: Vec<_> = updates_per_symbol.iter().collect();
    sorted_updates.sort_by(|a, b| b.1.cmp(a.1));

    for (idx, count) in sorted_updates.iter().take(10) {
        let symbol = index_to_symbol.get(idx).unwrap();
        let (bid, ask) = sample_prices.get(idx).unwrap_or(&(0.0, 0.0));
        println!(
            "    {} (idx={}): {} updates, bid={:.6}, ask={:.6}",
            symbol, idx, count, bid, ask
        );
    }
    if sorted_updates.len() > 10 {
        println!("    ... and {} more symbols", sorted_updates.len() - 10);
    }

    assert!(total_updates > 0, "Should receive updates");
    assert!(
        updates_per_symbol.len() > 5,
        "Should receive updates from multiple symbols"
    );

    println!("\n[PASS] Triangular arbitrage WebSocket working correctly\n");
    Ok(())
}
